import React, { useState, useEffect, useRef } from "react";
import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { getStorage, ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";

// --- Mock Data File: data/locations.js ---
const locations = {
  "Dar Es Salaam": {
    "Ilala": ["Buguruni", "Chanika", "Gerezani", "Ilala", "Jangwani", "Kariakoo", "Kivukoni", "Kinyerezi", "Kisutu", "Kitunda", "Mchafukoge", "Msongola", "Pugu", "Segerea", "Tabata", "Ukonga", "Upanga East", "Upanga West", "Vingunguti"],
    "Kinondoni": ["Bunju", "Hananasif", "Kawe", "Kigogo", "Kijitonyama", "Kinondoni", "Kunduchi", "Mabibo", "Magomeni", "Makumbusho", "Manzese", "Mbezi", "Mbezi Juu", "Mikocheni", "Msasani", "Mwananyamala", "Mwenge", "Ndugumbi", "Sinza", "Tandale", "Ubungo", "Wazo"],
    "Temeke": ["Azimio", "Buza", "Chamazi", "Chang'ombe", "Keko", "Kigamboni", "Kijichi", "Kilakala", "Kurasini", "Makangarawe", "Mbagala", "Mbagala Kuu", "Miburani", "Mjimwema", "Mtoni", "Pemba Mnazi", "Sandali", "Somangira", "Tandika", "Temeke", "Toangoma", "Vijibweni", "Yombo Vituka"],
    "Kigamboni": ["Kibada", "Kigamboni", "Mjimwema", "Somangira", "Tungi", "Vijibweni"],
    "Ubungo": ["Goba", "Kawe", "Kibamba", "Kimara", "Kwembe", "Makuburi", "Makuyuni", "Mbezi", "Msigani", "Saranga"]
  }
};

// --- Firebase Configuration ---
const firebaseConfig = typeof __firebase_config !== 'undefined' ? JSON.parse(__firebase_config) : {
    apiKey: "YOUR_API_KEY", authDomain: "YOUR_AUTH_DOMAIN", projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET", messagingSenderId: "YOUR_MESSAGING_SENDER_ID", appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);
const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-app-id';

// --- Helper & Reusable Components ---
const InputField = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-gray-700 text-sm font-medium mb-2">{label}</label>
        <input id={id} {...props} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition duration-200" />
    </div>
);

const TextAreaField = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-gray-700 text-sm font-medium mb-2">{label}</label>
        <textarea id={id} {...props} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition duration-200"></textarea>
    </div>
);

const SelectField = ({ label, id, options, placeholder, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-gray-700 text-sm font-medium mb-2">{label}</label>
        <select id={id} {...props} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-100 transition duration-200">
            <option value="">{placeholder}</option>
            {options.map((opt) => (<option key={opt} value={opt}>{opt}</option>))}
        </select>
    </div>
);

const FileField = ({ label, id, fileName, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-gray-700 text-sm font-medium mb-2">{label}</label>
        <input type="file" id={id} {...props} className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" />
        {fileName && <p className="text-sm text-gray-500 mt-2">File: {fileName}</p>}
    </div>
);

const ProgressBar = ({ currentStep, steps }) => (
    <div className="w-full mb-8">
        <div className="flex justify-between items-start">
            {steps.map((step, index) => (
                <React.Fragment key={index}>
                    <div className="flex flex-col items-center w-20 text-center">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 ${index + 1 <= currentStep ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'}`}>
                            {index + 1}
                        </div>
                        <p className={`mt-2 text-xs font-medium ${index + 1 <= currentStep ? 'text-blue-600' : 'text-gray-500'}`}>{step}</p>
                    </div>
                    {index < steps.length - 1 && (
                        <div className={`flex-1 h-1 mt-5 mx-2 transition-all duration-300 ${index + 1 < currentStep ? 'bg-blue-600' : 'bg-gray-200'}`}></div>
                    )}
                </React.Fragment>
            ))}
        </div>
    </div>
);


// --- Main Form Component ---
function ReportingForm() {
    const initialFormData = {
        reportType: "", hideIdentity: "Hapana", reporterIdType: "NIDA", nidaNumber: "", reporterName: "",
        district: "", ward: "", streetVillageHamlet: "", postalCode: "", latitude: "", longitude: "",
        eventDate: "", eventTime: "", eventType: "", detailedDescription: "",
        evidenceUpload: null, department: "",
    };

    const [formData, setFormData] = useState(initialFormData);
    const [message, setMessage] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const [userId, setUserId] = useState(null);
    const [currentStep, setCurrentStep] = useState(1);
    const [wards, setWards] = useState([]);
    const [locationMessage, setLocationMessage] = useState("");

    const steps = ["Taarifa", "Mtoa Taarifa", "Eneo", "Maelezo", "Ushahidi", "Thibitisha"];
    const dynamicSteps = formData.hideIdentity === 'Ndiyo' ? steps.filter(step => step !== "Mtoa Taarifa") : steps;

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, async (user) => {
            if (user) setUserId(user.uid);
            else {
                try {
                    const token = typeof __initial_auth_token !== 'undefined' ? __initial_auth_token : null;
                    if (token) await signInWithCustomToken(auth, token);
                    else await signInAnonymously(auth);
                } catch (error) { console.error("Auth Error:", error); setMessage("Authentication failed."); }
            }
        });
        return () => unsubscribe();
    }, []);

    const handleDistrictChange = (e) => {
        const district = e.target.value;
        setFormData({ ...formData, district: district, ward: "" });
        if (district && locations["Dar Es Salaam"] && locations["Dar Es Salaam"][district]) {
            setWards(Object.values(locations["Dar Es Salaam"][district]).flat().sort());
        } else {
            setWards([]);
        }
    };

    const handleChange = (e) => {
        const { name, value, files } = e.target;
        setFormData({ ...formData, [name]: files ? files[0] : value });
    };

    const handleGetLocation = () => {
        if (navigator.geolocation) {
            setLocationMessage("Inapata eneo lako...");
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    setFormData(prev => ({ ...prev, latitude: position.coords.latitude, longitude: position.coords.longitude }));
                    setLocationMessage("Eneo limepatikana!");
                },
                (error) => {
                    console.error("Geolocation error:", error);
                    let errorMessage = "Imeshindwa kupata eneo. ";
                    switch (error.code) {
                        case error.PERMISSION_DENIED: errorMessage += "Umekataa ruhusa ya eneo."; break;
                        case error.POSITION_UNAVAILABLE: errorMessage += "Taarifa za eneo lako hazipatikani."; break;
                        case error.TIMEOUT: errorMessage += "Ombi limechukua muda mrefu."; break;
                        default: errorMessage += "Kuna kosa lisilojulikana limetokea."; break;
                    }
                    setLocationMessage(errorMessage);
                },
                { timeout: 10000 }
            );
        } else {
            setLocationMessage("Kifaa chako hakiruhusu upatikanaji wa eneo.");
        }
    };

    const uploadFile = (file, path) => new Promise((resolve, reject) => {
        const uploadTask = uploadBytesResumable(ref(storage, path), file);
        uploadTask.on('state_changed', () => {}, reject, () => { getDownloadURL(uploadTask.snapshot.ref).then(resolve).catch(reject); });
    });

    const handleSubmit = async () => {
        if (!userId) { setMessage("Error: User not authenticated."); return; }
        setMessage("");
        setIsLoading(true);

        try {
            const evidenceUrl = formData.evidenceUpload ? await uploadFile(formData.evidenceUpload, `users/${userId}/reports/${Date.now()}_${formData.evidenceUpload.name}`) : "";
            const dataToSave = { ...formData, evidenceUrl, evidenceUpload: null, timestamp: serverTimestamp(), status: 'pending', userId, appId };
            
            await addDoc(collection(db, `artifacts/${appId}/users/${userId}/reports`), dataToSave);

            setMessage("Taarifa imewasilishwa kwa mafanikio!");
            setFormData(initialFormData);
            setCurrentStep(1);
        } catch (error) {
            setMessage("Kuna tatizo wakati wa kuwasilisha taarifa. Jaribu tena.");
            console.error("Error adding document: ", error);
        } finally {
            setIsLoading(false);
        }
    };

    const validateStep = () => {
        let stepIndex = currentStep;
        if (formData.hideIdentity === 'Ndiyo' && currentStep > 1) {
            stepIndex = currentStep + 1; // Adjust index if reporter step is skipped
        }

        switch (stepIndex) {
            case 1: return formData.reportType;
            case 2: return true; // Reporter info is now optional
            case 3: return formData.district && formData.ward && formData.streetVillageHamlet && formData.postalCode;
            case 4: return formData.eventDate && formData.eventType && formData.detailedDescription && formData.department;
            case 5: return true; // Evidence is optional
            default: return true;
        }
    };

    const nextStep = () => {
        if (validateStep()) {
            setMessage("");
            let next = currentStep + 1;
            if (formData.hideIdentity === 'Ndiyo' && currentStep === 1) {
                next = currentStep + 2; // Skip reporter info step
            }
            setCurrentStep(next);
        } else {
            setMessage("Tafadhali jaza sehemu zote zinazohitajika (*).");
        }
    };

    const prevStep = () => {
        let prev = currentStep - 1;
        if (formData.hideIdentity === 'Ndiyo' && currentStep === 3) {
            prev = currentStep - 2; // Skip back over reporter info step
        }
        setCurrentStep(prev);
    };
    
    const renderStepContent = () => {
        let stepIndex = currentStep;
        if (formData.hideIdentity === 'Ndiyo' && currentStep > 1