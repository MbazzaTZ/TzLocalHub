import React, { useState, useEffect, useRef } from "react";
import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { getStorage, ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";

// --- Mock Data File: data/locations.js ---
const locations = {
  "Dar Es Salaam": {
    "Ilala": ["Buguruni", "Chanika", "Gerezani", "Ilala", "Jangwani", "Kariakoo", "Kivukoni", "Kinyerezi", "Kisutu", "Kitunda", "Mchafukoge", "Msongola", "Pugu", "Segerea", "Tabata", "Ukonga", "Upanga East", "Upanga West", "Vingunguti"],
    "Kinondoni": ["Bunju", "Hananasif", "Kawe", "Kigogo", "Kijitonyama", "Kinondoni", "Kunduchi", "Mabibo", "Magomeni", "Makumbusho", "Manzese", "Mbezi", "Mbezi Juu", "Mikocheni", "Msasani", "Mwananyamala", "Mwenge", "Ndugumbi", "Sinza", "Tandale", "Ubungo", "Wazo"],
    "Temeke": ["Azimio", "Buza", "Chamazi", "Chang'ombe", "Keko", "Kigamboni", "Kijichi", "Kilakala", "Kurasini", "Makangarawe", "Mbagala", "Mbagala Kuu", "Miburani", "Mjimwema", "Mtoni", "Pemba Mnazi", "Sandali", "Somangira", "Tandika", "Temeke", "Toangoma", "Vijibweni", "Yombo Vituka"],
    "Kigamboni": ["Kibada", "Kigamboni", "Mjimwema", "Somangira", "Tungi", "Vijibweni"],
    "Ubungo": ["Goba", "Kawe", "Kibamba", "Kimara", "Kwembe", "Makuburi", "Makuyuni", "Mbezi", "Msigani", "Saranga"]
  },
  "Arusha": {
    "Arusha City": ["Baraa", "Daraja Mbili", "Elerai", "Kaloleni", "Kati", "Kimandolu", "Lemara", "Levolosi", "Moshono", "Ngarenaro", "Olasiti", "Oljoro", "Oloirien", "Sekei", "Sokon I", "Sombetini", "Terrat", "Themi", "Unga L.T.D"],
    "Arusha Rural": ["Bangata", "Bwawani", "Ilkiding'a", "Kimnyaki", "Kiranyi", "Kisongo", "Mateves", "Mlangarini", "Moivo", "Musa", "Oldonyosambu", "Oljoro", "Olorieni", "Oltoroto", "Oltrumet", "Sambasha", "Sokon II"],
    "Karatu": ["Baray", "Buger", "Daa", "Endabash", "Endamarariek", "Ganako", "Karatu", "Mang'ola", "Mbulumbulu", "Oldeani", "Qurus", "Rhotia"]
  },
  "Mwanza": {
      "Ilemela": ["Bugogwa", "Buswelu", "Butimba", "Ilemela", "Kirumba", "Kitangiri", "Nyakato", "Pasiansi", "Sangabuye"],
      "Nyamagana": ["Buhongwa", "Butimba", "Igogo", "Igoma", "Isamilo", "Mahina", "Mbugani", "Mirongo", "Mkolani", "Nyamagana", "Pamba"]
  }
};

// --- Mock NIDA Database ---
const nidaDatabase = {
    "19900101-12345-12345-01": { fullName: "Asha Juma", phoneNumber: "0712345678", mobileNumber: "0787654321", email: "asha.juma@example.com" },
    "19850510-54321-54321-02": { fullName: "John Doe", phoneNumber: "0755123456", mobileNumber: "", email: "john.doe@example.com" },
    "20001225-11223-34455-03": { fullName: "Fatuma Bakari", phoneNumber: "0688987654", mobileNumber: "0655112233", email: "fatuma.b@example.com" }
};

// --- Permit Subtypes with Fees ---
const permitSubTypesData = {
    "Kibali cha Ujenzi": [
        { name: "Nyumba ya Makazi", fee: 150000 },
        { name: "Ghorofa (kwa kila sakafu)", fee: 250000 },
        { name: "Fremu ya Biashara", fee: 100000 },
        { name: "Uzio/Ukuta", fee: 50000 },
        { name: "Ukarabati Mkubwa", fee: 75000 },
        { name: "Kibali cha Matumizi (Occupancy)", fee: 120000 },
        { name: "Nyingineyo", fee: 40000 }
    ],
    "Kibali cha Mazishi": [
        { name: "Ndani ya Wilaya", fee: 10000 },
        { name: "Nje ya Wilaya", fee: 25000 },
        { name: "Kutoka Nje ya Nchi", fee: 100000 }
    ],
    "Kibali cha Sherehe": [
        { name: "Harusi (Ukumbi)", fee: 50000 },
        { name: "Harusi (Nyumbani)", fee: 20000 },
        { name: "Sherehe ya Kuzaliwa", fee: 15000 },
        { name: "Kumbukumbu", fee: 10000 },
        { name: "Tamasha la Muziki", fee: 200000 },
        { name: "Nyingineyo", fee: 25000 }
    ],
    "Kibali cha Mikutano": [
        { name: "Mkutano wa Kisiasa", fee: 150000 },
        { name: "Mkutano wa Kidini", fee: 30000 },
        { name: "Mkutano wa Kibiashara", fee: 75000 },
        { name: "Mkutano wa Hadhara", fee: 40000 },
        { name: "Nyingineyo", fee: 20000 }
    ]
};


// --- Firebase Configuration ---
const firebaseConfig = typeof __firebase_config !== 'undefined' ? JSON.parse(__firebase_config) : {
    apiKey: "YOUR_API_KEY", authDomain: "YOUR_AUTH_DOMAIN", projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET", messagingSenderId: "YOUR_MESSAGING_SENDER_ID", appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);
const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-app-id';

// --- Helper & Reusable Components ---
const InputField = ({ label, id, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-gray-700 text-sm font-medium mb-2">{label}</label>
        <input id={id} {...props} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition duration-200" />
    </div>
);

const SelectField = ({ label, id, options, placeholder, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-gray-700 text-sm font-medium mb-2">{label}</label>
        <select id={id} {...props} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-100 transition duration-200">
            <option value="">{placeholder}</option>
            {options.map((opt) => (<option key={typeof opt === 'object' ? opt.name : opt} value={typeof opt === 'object' ? opt.name : opt}>{typeof opt === 'object' ? opt.name : opt}</option>))}
        </select>
    </div>
);

const FileField = ({ label, id, fileName, ...props }) => (
    <div>
        <label htmlFor={id} className="block text-gray-700 text-sm font-medium mb-2">{label}</label>
        <input type="file" id={id} {...props} className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" />
        {fileName && <p className="text-sm text-gray-500 mt-2">File: {fileName}</p>}
    </div>
);

const ProgressBar = ({ currentStep, steps }) => (
    <div className="w-full mb-8">
        <div className="flex justify-between items-start">
            {steps.map((step, index) => (
                <React.Fragment key={index}>
                    <div className="flex flex-col items-center w-20 text-center">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 ${index + 1 <= currentStep ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'}`}>
                            {index + 1}
                        </div>
                        <p className={`mt-2 text-xs font-medium ${index + 1 <= currentStep ? 'text-blue-600' : 'text-gray-500'}`}>{step}</p>
                    </div>
                    {index < steps.length - 1 && (
                        <div className={`flex-1 h-1 mt-5 mx-2 transition-all duration-300 ${index + 1 < currentStep ? 'bg-blue-600' : 'bg-gray-200'}`}></div>
                    )}
                </React.Fragment>
            ))}
        </div>
    </div>
);


// --- Main Form Component ---
function PermitRequestForm() {
    const initialFormData = {
        permitType: "", detailedPermitType: "", fee: "",
        idType: "NIDA", idNumber: "", fullName: "", phoneNumber: "", mobileNumber: "", email: "",
        applicantDistrict: "", applicantWard: "", applicantStreet: "",
        document: null,
    };

    const [formData, setFormData] = useState(initialFormData);
    const [message, setMessage] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const [userId, setUserId] = useState(null);
    const [currentStep, setCurrentStep] = useState(1);
    const [lookupMessage, setLookupMessage] = useState("");

    const steps = ["Aina", "Maelezo", "Mwombaji", "Anuani", "Nyaraka", "Thibitisha"];
    const [applicantWards, setApplicantWards] = useState([]);

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, async (user) => {
            if (user) setUserId(user.uid);
            else {
                try {
                    const token = typeof __initial_auth_token !== 'undefined' ? __initial_auth_token : null;
                    if (token) await signInWithCustomToken(auth, token);
                    else await signInAnonymously(auth);
                } catch (error) { console.error("Auth Error:", error); setMessage("Authentication failed."); }
            }
        });
        return () => unsubscribe();
    }, []);

    const handlePermitTypeChange = (e) => {
        const type = e.target.value;
        setFormData({ ...formData, permitType: type, detailedPermitType: "", fee: "" });
    };
    
    const handleDetailedPermitTypeChange = (e) => {
        const selectedSubTypeName = e.target.value;
        const permitType = formData.permitType;
        let fee = "";
        if(permitType && permitSubTypesData[permitType]){
            const selectedSubType = permitSubTypesData[permitType].find(sub => sub.name === selectedSubTypeName);
            if(selectedSubType){
                fee = selectedSubType.fee;
            }
        }
        setFormData({...formData, detailedPermitType: selectedSubTypeName, fee: fee});
    };

    const handleApplicantDistrictChange = (e) => {
        const district = e.target.value;
        setFormData({ ...formData, applicantDistrict: district, applicantWard: "" });
        if (district && locations["Dar Es Salaam"] && locations["Dar Es Salaam"][district]) {
            setApplicantWards(Object.values(locations["Dar Es Salaam"][district]).flat().sort());
        } else {
            setApplicantWards([]);
        }
    };

    const handleChange = (e) => {
        const { name, value, files } = e.target;
        setFormData({ ...formData, [name]: files ? files[0] : value });
    };
    
    const handleNidaBlur = (e) => {
        const idNumber = e.target.value;
        if (formData.idType === 'NIDA' && idNumber) {
            setLookupMessage("Checking NIDA number...");
            setTimeout(() => {
                const userData = nidaDatabase[idNumber];
                if (userData) {
                    setFormData(prev => ({ ...prev, ...userData }));
                    setLookupMessage("Details auto-filled successfully.");
                } else {
                    setLookupMessage("NIDA number not found.");
                }
            }, 1000);
        } else {
            setLookupMessage("");
        }
    };

    const uploadFile = (file, path) => new Promise((resolve, reject) => {
        const uploadTask = uploadBytesResumable(ref(storage, path), file);
        uploadTask.on('state_changed', () => {}, reject, () => {
            getDownloadURL(uploadTask.snapshot.ref).then(resolve).catch(reject);
        });
    });

    const handleSubmit = async () => {
        if (!userId) { setMessage("Error: User not authenticated."); return; }
        setMessage("");
        setIsLoading(true);

        try {
            const documentUrl = formData.document ? await uploadFile(formData.document, `users/${userId}/permitRequests/${Date.now()}_${formData.document.name}`) : "";
            const dataToSave = { ...formData, documentUrl, document: null, timestamp: serverTimestamp(), status: 'pending', userId, appId };
            
            await addDoc(collection(db, `artifacts/${appId}/users/${userId}/permitRequests`), dataToSave);

            setMessage("Ombi la Kibali limewasilishwa kwa mafanikio!");
            setFormData(initialFormData);
            setCurrentStep(1);
        } catch (error) {
            setMessage("Kuna tatizo wakati wa kuwasilisha ombi. Jaribu tena.");
            console.error("Error adding document: ", error);
        } finally {
            setIsLoading(false);
        }
    };

    const validateStep = () => {
        switch (currentStep) {
            case 1: return formData.permitType;
            case 2: return formData.detailedPermitType;
            case 3: return formData.idType && formData.idNumber && formData.fullName && formData.phoneNumber;
            case 4: return formData.applicantDistrict && formData.applicantWard && formData.applicantStreet;
            case 5: return true; // Document is optional
            default: return true;
        }
    };

    const nextStep = () => {
        if (validateStep()) {
            setMessage("");
            setCurrentStep(prev => prev < steps.length ? prev + 1 : prev);
        } else {
            setMessage("Tafadhali jaza sehemu zote zinazohitajika (*).");
        }
    };

    const prevStep = () => setCurrentStep(prev => prev > 1 ? prev - 1 : prev);

    return (
        <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4 font-sans">
            {isLoading && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
                    <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-white"></div>
                </div>
            )}
            <div className="bg-white rounded-xl shadow-2xl p-8 max-w-4xl w-full">
                <h2 className="text-3xl font-bold text-gray-800 mb-4 text-center">Fomu ya Ombi la Kibali</h2>
                <p className="text-center text-gray-500 mb-8">Tafadhali fuata hatua zote kukamilisha ombi lako.</p>

                <ProgressBar currentStep={currentStep} steps={steps} />

                {message && (
                    <div className={`p-3 my-4 rounded-md text-center ${message.includes("mafanikio") ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                        {message}
                    </div>
                )}

                <div className="mt-8 min-h-[300px]">
                    {currentStep === 1 && (
                        <section className="space-y-6 animate-fadeIn">
                            <h3 className="text-2xl font-semibold text-gray-700">Hatua 1: Aina ya Kibali</h3>
                            <SelectField label="Aina ya Kibali*" id="permitType" name="permitType" value={formData.permitType} onChange={handlePermitTypeChange} options={Object.keys(permitSubTypesData)} placeholder="-- Chagua aina ya kibali --" required />
                        </section>
                    )}
                    {currentStep === 2 && (
                         <section className="space-y-6 animate-fadeIn">
                            <h3 className="text-2xl font-semibold text-gray-700">Hatua 2: Maelezo ya Kibali</h3>
                            <SelectField label="Aina ya Kibali kwa Undani*" id="detailedPermitType" name="detailedPermitType" value={formData.detailedPermitType} onChange={handleDetailedPermitTypeChange} options={permitSubTypesData[formData.permitType] || []} placeholder="-- Chagua kwa undani --" disabled={!formData.permitType} required />
                            {formData.fee && (
                                <div>
                                    <label className="block text-gray-700 text-sm font-medium mb-2">Ada (TSh)</label>
                                    <p className="w-full px-4 py-2 border border-gray-200 rounded-lg bg-gray-100">{Number(formData.fee).toLocaleString()} TSh</p>
                                </div>
                            )}
                        </section>
                    )}
                     {currentStep === 3 && (
                         <section className="space-y-6 animate-fadeIn">
                            <h3 className="text-2xl font-semibold text-gray-700">Hatua 3: Taarifa za Mwombaji</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <SelectField label="Aina ya Kitambulisho*" id="idType" name="idType" value={formData.idType} onChange={handleChange} options={["NIDA", "Passport", "Driver's License", "Voter's ID"]} placeholder="-- Chagua Aina --" required />
                                <InputField label="Namba ya Kitambulisho*" id="idNumber" name="idNumber" value={formData.idNumber} onChange={handleChange} onBlur={handleNidaBlur} required />
                                {lookupMessage && <p className="text-sm text-blue-600 md:col-span-2">{lookupMessage}</p>}
                                <InputField label="Jina Kamili*" id="fullName" name="fullName" value={formData.fullName} onChange={handleChange} required />
                                <InputField label="Namba ya Simu*" id="phoneNumber" name="phoneNumber" type="tel" value={formData.phoneNumber} onChange={handleChange} required />
                                <InputField label="Barua Pepe" id="email" name="email" type="email" value={formData.email} onChange={handleChange} className="md:col-span-2"/>
                            </div>
                        </section>
                    )}
                    {currentStep === 4 && (
                        <section className="space-y-6 animate-fadeIn">
                            <h3 className="text-2xl font-semibold text-gray-700">Hatua 4: Anuani ya Mwombaji (Dar es Salaam)</h3>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <SelectField label="Wilaya*" id="applicantDistrict" name="applicantDistrict" value={formData.applicantDistrict} onChange={handleApplicantDistrictChange} options={Object.keys(locations["Dar Es Salaam"])} placeholder="-- Chagua Wilaya --" required />
                                <SelectField label="Kata*" id="applicantWard" name="applicantWard" value={formData.applicantWard} onChange={handleChange} options={applicantWards} placeholder={formData.applicantDistrict ? "-- Chagua Kata --" : "-- Chagua Wilaya Kwanza --"} disabled={!formData.applicantDistrict} required />
                                <InputField label="Mtaa*" id="applicantStreet" name="applicantStreet" value={formData.applicantStreet} onChange={handleChange} required />
                            </div>
                        </section>
                    )}
                    {currentStep === 5 && (
                        <section className="space-y-6 animate-fadeIn">
                            <h3 className="text-2xl font-semibold text-gray-700">Hatua 5: Pakia Nyaraka</h3>
                            <p className="text-sm text-gray-600">Ikiwa inahitajika, pakia nyaraka husika (k.m. mchoro wa jengo, barua, n.k.).</p>
                            <FileField label="Nyaraka" id="document" name="document" onChange={handleChange} accept="image/*,application/pdf" fileName={formData.document?.name}/>
                        </section>
                    )}
                    {currentStep === 6 && (
                        <section className="animate-fadeIn">
                            <h3 className="text-2xl font-semibold text-gray-700 mb-4">Hatua 6: Hakiki na Wasilisha</h3>
                            <div className="space-y-4 bg-gray-50 p-6 rounded-lg">
                                {Object.entries(formData).map(([key, value]) => {
                                    if (!value || (typeof value === 'object' && !value.name)) return null;
                                    const label = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
                                    const displayValue = key === 'fee' ? `${Number(value).toLocaleString()} TSh` : (typeof value === 'object' ? value.name : value);
                                    return (
                                        <div key={key} className="flex flex-col sm:flex-row sm:justify-between border-b py-2">
                                            <span className="font-semibold text-gray-600">{label}:</span>
                                            <span className="text-gray-800 text-left sm:text-right">{displayValue}</span>
                                        </div>
                                    );
                                })}
                                 {formData.document && (
                                    <div className="pt-4">
                                        <h4 className="font-semibold text-gray-600 mb-2">Nyaraka Iliyopakiwa:</h4>
                                        {formData.document.type.startsWith("image/") ? (
                                             <img src={URL.createObjectURL(formData.document)} alt="Document Preview" className="rounded-lg shadow-md max-h-48"/>
                                        ) : (
                                            <p className="text-gray-800">{formData.document.name}</p>
                                        )}
                                    </div>
                                )}
                            </div>
                        </section>
                    )}
                </div>

                {/* Navigation Buttons */}
                <div className="flex justify-between mt-10">
                    <button onClick={prevStep} disabled={currentStep === 1} className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-6 rounded-lg shadow-md transition duration-200 disabled:bg-gray-200 disabled:cursor-not-allowed">
                        Nyuma
                    </button>
                    {currentStep < steps.length ? (
                        <button onClick={nextStep} disabled={!validateStep()} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-lg shadow-md transition duration-200 disabled:bg-blue-300 disabled:cursor-not-allowed">
                            Mbele
                        </button>
                    ) : (
                        <button onClick={handleSubmit} disabled={isLoading} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-lg shadow-md transition duration-200">
                           {isLoading ? 'Inawasilisha...' : 'Wasilisha Ombi'}
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
}

// --- Main App Component ---
export default function App() {
  return <PermitRequestForm />;
}
