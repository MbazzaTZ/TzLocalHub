import React, { useEffect, useState, useCallback } from "react";
import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged, signOut as firebaseSignOut, createUserWithEmailAndPassword, signInWithEmailAndPassword, sendPasswordResetEmail } from 'firebase/auth';
import { getFirestore, doc, getDoc, setDoc } from 'firebase/firestore';

// --- Firebase Configuration and Initialization ---
// Global variables provided by the Canvas environment for Firebase setup.
// These variables are essential for connecting to the Firebase project.
const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-app-id';
const firebaseConfig = typeof __firebase_config !== 'undefined' ? JSON.parse(__firebase_config) : {};
const initialAuthToken = typeof __initial_auth_token !== 'undefined' ? __initial_auth_token : null;

// Initialize Firebase application
const app = initializeApp(firebaseConfig);
// Get Firebase Authentication and Firestore instances
const auth = getAuth(app);
const db = getFirestore(app);

/**
 * Initializes Firebase authentication.
 * Attempts to sign in with a custom token if available, otherwise signs in anonymously.
 * This ensures a user session is established for Firestore interactions.
 */
const initializeAuth = async () => {
  try {
    if (initialAuthToken) {
      await signInWithCustomToken(auth, initialAuthToken);
      console.log("Signed in with custom token.");
    } else {
      await signInAnonymously(auth);
      console.log("Signed in anonymously.");
    }
  } catch (error) {
    console.error("Error during Firebase initialization:", error);
  }
};

// --- Helper Components for UI ---

/**
 * A simple loading spinner component.
 * @returns {JSX.Element} The loading spinner UI.
 */
const LoadingSpinner = () => (
  <div className="flex items-center justify-center min-h-screen bg-gray-100 dark:bg-gray-900">
    <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-blue-500"></div>
    <h3 className="ml-4 text-xl font-semibold text-gray-700 dark:text-gray-300">Loading...</h3>
  </div>
);

/**
 * A reusable button component with Tailwind styling.
 * @param {object} props - Component props.
 * @param {function} props.onClick - The click handler for the button.
 * @param {string} props.children - The content of the button.
 * @param {string} [props.className] - Additional CSS classes.
 * @returns {JSX.Element} The button UI.
 */
const Button = ({ onClick, children, className = "" }) => (
  <button
    onClick={onClick}
    className={`w-full px-4 py-2 rounded-lg text-white font-semibold shadow-md transition duration-300 ease-in-out transform hover:scale-105
      bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 ${className}`}
  >
    {children}
  </button>
);

/**
 * A reusable input field component with Tailwind styling.
 * @param {object} props - Component props.
 * @param {string} props.type - The type of the input (e.g., "text", "email", "password").
 * @param {string} props.placeholder - The placeholder text.
 * @param {string} props.value - The current value of the input.
 * @param {function} props.onChange - The change handler for the input.
 * @param {string} [props.className] - Additional CSS classes.
 * @returns {JSX.Element} The input UI.
 */
const Input = ({ type, placeholder, value, onChange, className = "" }) => (
  <input
    type={type}
    placeholder={placeholder}
    value={value}
    onChange={onChange}
    className={`w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500
      dark:bg-gray-700 dark:border-gray-600 dark:text-white ${className}`}
  />
);

// --- Page Components ---

/**
 * Home Page Component.
 * Provides navigation links to Login, Register, Admin Dashboard, and Mwananchi Dashboard.
 * @param {object} props - Component props.
 * @param {function} props.setCurrentPath - Function to navigate to a different path.
 * @param {object|null} props.user - The current authenticated user object, or null if not logged in.
 * @param {string|null} props.role - The role of the current user, or null.
 * @returns {JSX.Element} The Home page UI.
 */
const Home = ({ setCurrentPath, user, role }) => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-blue-100 to-purple-100 dark:from-gray-800 dark:to-gray-900 p-4">
      <div className="bg-white dark:bg-gray-800 p-8 rounded-xl shadow-2xl w-full max-w-md text-center">
        <h1 className="text-4xl font-extrabold text-gray-800 dark:text-white mb-6">Welcome Home!</h1>
        {user ? (
          <p className="text-lg text-gray-700 dark:text-gray-300 mb-6">
            You are logged in as <span className="font-bold text-blue-600 dark:text-blue-400">{user.email}</span> with role <span className="font-bold text-purple-600 dark:text-purple-400">{role}</span>.
          </p>
        ) : (
          <p className="text-lg text-gray-700 dark:text-gray-300 mb-6">Please log in or register to continue.</p>
        )}

        <div className="space-y-4">
          {!user && (
            <>
              <Button onClick={() => setCurrentPath("/login")}>Go to Login</Button>
              <Button onClick={() => setCurrentPath("/register")} className="bg-green-600 hover:bg-green-700">Go to Register</Button>
            </>
          )}
          {user && role === "admin" && (
            <Button onClick={() => setCurrentPath("/admin")} className="bg-purple-600 hover:bg-purple-700">Go to Admin Dashboard</Button>
          )}
          {user && role === "mwananchi" && (
            <Button onClick={() => setCurrentPath("/mwananchi")} className="bg-teal-600 hover:bg-teal-700">Go to Mwananchi Dashboard</Button>
          )}
          {!user && (
            <Button onClick={() => setCurrentPath("/reset")} className="bg-yellow-600 hover:bg-yellow-700">Reset Password</Button>
          )}
        </div>
      </div>
    </div>
  );
};

/**
 * Login Page Component.
 * Handles user login with email and password.
 * @param {object} props - Component props.
 * @param {function} props.setCurrentPath - Function to navigate to a different path.
 * @returns {JSX.Element} The Login page UI.
 */
const Login = ({ setCurrentPath }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    setLoading(true);
    setError("");
    try {
      await signInWithEmailAndPassword(auth, email, password);
      // On successful login, onAuthStateChanged in App.js will handle redirection
      console.log("User logged in successfully!");
    } catch (err) {
      console.error("Login error:", err.message);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-100 to-purple-100 dark:from-gray-800 dark:to-gray-900 p-4">
      <div className="bg-white dark:bg-gray-800 p-8 rounded-xl shadow-2xl w-full max-w-md">
        <h2 className="text-3xl font-extrabold text-gray-800 dark:text-white mb-6 text-center">Login</h2>
        {error && <p className="text-red-500 text-center mb-4">{error}</p>}
        <div className="space-y-4">
          <Input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <Input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <Button onClick={handleLogin} disabled={loading}>
            {loading ? "Logging In..." : "Login"}
          </Button>
        </div>
        <p className="mt-6 text-center text-gray-700 dark:text-gray-300">
          Don't have an account?{" "}
          <span
            onClick={() => setCurrentPath("/register")}
            className="text-blue-600 dark:text-blue-400 hover:underline cursor-pointer font-medium"
          >
            Register
          </span>
        </p>
        <p className="mt-2 text-center text-gray-700 dark:text-gray-300">
          Forgot password?{" "}
          <span
            onClick={() => setCurrentPath("/reset")}
            className="text-blue-600 dark:text-blue-400 hover:underline cursor-pointer font-medium"
          >
            Reset
          </span>
        </p>
        <p className="mt-6 text-center text-gray-700 dark:text-gray-300">
          <span
            onClick={() => setCurrentPath("/")}
            className="text-gray-600 dark:text-gray-400 hover:underline cursor-pointer font-medium"
          >
            Back to Home
          </span>
        </p>
      </div>
    </div>
  );
};

/**
 * Register Page Component.
 * Handles new user registration with email and password, and assigns a default role.
 * @param {object} props - Component props.
 * @param {function} props.setCurrentPath - Function to navigate to a different path.
 * @returns {JSX.Element} The Register page UI.
 */
const Register = ({ setCurrentPath }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleRegister = async () => {
    setLoading(true);
    setError("");
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Store user role in Firestore
      const userDocRef = doc(db, "users", user.uid);
      await setDoc(userDocRef, {
        email: user.email,
        role: "mwananchi", // Default role for new registrations
        createdAt: new Date(),
      });

      console.log("User registered and role set successfully!");
      setCurrentPath("/login"); // Redirect to login after successful registration
    } catch (err) {
      console.error("Registration error:", err.message);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-100 to-teal-100 dark:from-gray-800 dark:to-gray-900 p-4">
      <div className="bg-white dark:bg-gray-800 p-8 rounded-xl shadow-2xl w-full max-w-md">
        <h2 className="text-3xl font-extrabold text-gray-800 dark:text-white mb-6 text-center">Register</h2>
        {error && <p className="text-red-500 text-center mb-4">{error}</p>}
        <div className="space-y-4">
          <Input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <Input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <Button onClick={handleRegister} disabled={loading} className="bg-green-600 hover:bg-green-700">
            {loading ? "Registering..." : "Register"}
          </Button>
        </div>
        <p className="mt-6 text-center text-gray-700 dark:text-gray-300">
          Already have an account?{" "}
          <span
            onClick={() => setCurrentPath("/login")}
            className="text-blue-600 dark:text-blue-400 hover:underline cursor-pointer font-medium"
          >
            Login
          </span>
        </p>
        <p className="mt-6 text-center text-gray-700 dark:text-gray-300">
          <span
            onClick={() => setCurrentPath("/")}
            className="text-gray-600 dark:text-gray-400 hover:underline cursor-pointer font-medium"
          >
            Back to Home
          </span>
        </p>
      </div>
    </div>
  );
};

/**
 * Reset Password Page Component.
 * Allows users to reset their password via email.
 * @param {object} props - Component props.
 * @param {function} props.setCurrentPath - Function to navigate to a different path.
 * @returns {JSX.Element} The Reset Password page UI.
 */
const ResetPassword = ({ setCurrentPath }) => {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleReset = async () => {
    setLoading(true);
    setMessage("");
    setError("");
    try {
      await sendPasswordResetEmail(auth, email);
      setMessage("Password reset email sent! Check your inbox.");
    } catch (err) {
      console.error("Password reset error:", err.message);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-yellow-100 to-orange-100 dark:from-gray-800 dark:to-gray-900 p-4">
      <div className="bg-white dark:bg-gray-800 p-8 rounded-xl shadow-2xl w-full max-w-md">
        <h2 className="text-3xl font-extrabold text-gray-800 dark:text-white mb-6 text-center">Reset Password</h2>
        {message && <p className="text-green-500 text-center mb-4">{message}</p>}
        {error && <p className="text-red-500 text-center mb-4">{error}</p>}
        <div className="space-y-4">
          <Input type="email" placeholder="Enter your email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <Button onClick={handleReset} disabled={loading} className="bg-yellow-600 hover:bg-yellow-700">
            {loading ? "Sending..." : "Send Reset Email"}
          </Button>
        </div>
        <p className="mt-6 text-center text-gray-700 dark:text-gray-300">
          <span
            onClick={() => setCurrentPath("/login")}
            className="text-blue-600 dark:text-blue-400 hover:underline cursor-pointer font-medium"
          >
            Back to Login
          </span>
        </p>
        <p className="mt-2 text-center text-gray-700 dark:text-gray-300">
          <span
            onClick={() => setCurrentPath("/")}
            className="text-gray-600 dark:text-gray-400 hover:underline cursor-pointer font-medium"
          >
            Back to Home
          </span>
        </p>
      </div>
    </div>
  );
};

/**
 * Admin Dashboard Component.
 * Accessible only to users with the 'admin' role.
 * @param {object} props - Component props.
 * @param {function} props.setCurrentPath - Function to navigate to a different path.
 * @param {object} props.user - The current authenticated user object.
 * @returns {JSX.Element} The Admin Dashboard UI.
 */
const AdminDashboard = ({ setCurrentPath, user }) => {
  const handleLogout = async () => {
    try {
      await firebaseSignOut(auth);
      setCurrentPath("/login"); // Redirect to login after logout
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-purple-100 to-indigo-100 dark:from-gray-800 dark:to-gray-900 p-4">
      <div className="bg-white dark:bg-gray-800 p-8 rounded-xl shadow-2xl w-full max-w-md text-center">
        <h2 className="text-3xl font-extrabold text-gray-800 dark:text-white mb-6">Admin Dashboard</h2>
        <p className="text-lg text-gray-700 dark:text-gray-300 mb-6">
          Welcome, <span className="font-bold text-purple-600 dark:text-purple-400">{user.email}</span>! You have administrative privileges.
        </p>
        <div className="space-y-4">
          <Button onClick={handleLogout} className="bg-red-600 hover:bg-red-700">Logout</Button>
          <Button onClick={() => setCurrentPath("/")} className="bg-gray-600 hover:bg-gray-700">Back to Home</Button>
        </div>
      </div>
    </div>
  );
};

/**
 * Mwananchi Dashboard Component.
 * Accessible only to users with the 'mwananchi' role.
 * @param {object} props - Component props.
 * @param {function} props.setCurrentPath - Function to navigate to a different path.
 * @param {object} props.user - The current authenticated user object.
 * @returns {JSX.Element} The Mwananchi Dashboard UI.
 */
const MwananchiDashboard = ({ setCurrentPath, user }) => {
  const handleLogout = async () => {
    try {
      await firebaseSignOut(auth);
      setCurrentPath("/login"); // Redirect to login after logout
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-teal-100 to-cyan-100 dark:from-gray-800 dark:to-gray-900 p-4">
      <div className="bg-white dark:bg-gray-800 p-8 rounded-xl shadow-2xl w-full max-w-md text-center">
        <h2 className="text-3xl font-extrabold text-gray-800 dark:text-white mb-6">Mwananchi Dashboard</h2>
        <p className="text-lg text-gray-700 dark:text-gray-300 mb-6">
          Hello, <span className="font-bold text-teal-600 dark:text-teal-400">{user.email}</span>! This is your citizen dashboard.
        </p>
        <div className="space-y-4">
          <Button onClick={handleLogout} className="bg-red-600 hover:bg-red-700">Logout</Button>
          <Button onClick={() => setCurrentPath("/")} className="bg-gray-600 hover:bg-gray-700">Back to Home</Button>
        </div>
      </div>
    </div>
  );
};

// --- Main App Component ---

/**
 * The main application component.
 * Manages authentication state, user roles, and handles routing using a switch-case approach.
 * It ensures that Firebase is initialized and authentication state is ready before rendering the main content.
 * @returns {JSX.Element} The main application UI.
 */
export default function App() {
  const [user, setUser] = useState(null);
  const [role, setRole] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [currentPath, setCurrentPath] = useState(window.location.pathname); // State to manage current path

  // Effect to initialize Firebase Auth and listen for auth state changes
  useEffect(() => {
    // Initialize Firebase Auth. This ensures the custom token or anonymous sign-in happens.
    initializeAuth().then(() => {
      setIsAuthReady(true); // Mark auth as ready after initial sign-in attempt
    });

    // Listen for authentication state changes. This listener will update `user` and `role` states.
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        try {
          // Fetch user role from Firestore.
          // The path for user documents is 'users/{userId}'.
          const userDocRef = doc(db, "users", currentUser.uid);
          const userDocSnap = await getDoc(userDocRef);

          if (userDocSnap.exists()) {
            // If user document exists, set the role from Firestore data.
            setRole(userDocSnap.data().role);
          } else {
            // If user document not found, log a warning and default to 'mwananchi' role.
            console.warn("User document not found in Firestore. Defaulting to mwananchi role.");
            setRole("mwananchi"); // Default role if not found
          }
        } catch (error) {
          // Log any errors during role fetching and fallback to 'mwananchi'.
          console.error("Error fetching user role:", error);
          setRole("mwananchi"); // Fallback in case of error
        }
      } else {
        // If no current user, clear user and role states.
        setUser(null);
        setRole(null);
      }
      setLoading(false); // Set loading to false once auth state is determined.
    });

    // Cleanup subscription on component unmount to prevent memory leaks.
    return () => unsubscribe();
  }, []); // Empty dependency array means this effect runs once on component mount.

  // Effect to update currentPath when the browser's URL changes (e.g., via back/forward buttons)
  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Function to handle navigation, updating the URL and currentPath state
  const handleNavigation = useCallback((path) => {
    window.history.pushState({}, '', path); // Update browser history
    setCurrentPath(path); // Update React state
  }, []);

  // Show loading spinner while authentication state is being determined
  if (loading || !isAuthReady) {
    return <LoadingSpinner />;
  }

  // Render content based on current path and user authentication/role
  let content;
  switch (currentPath) {
    case "/":
      content = <Home setCurrentPath={handleNavigation} user={user} role={role} />;
      break;
    case "/login":
      content = user ? (
        // If user is logged in, redirect to appropriate dashboard
        role === "admin" ? <AdminDashboard setCurrentPath={handleNavigation} user={user} /> : <MwananchiDashboard setCurrentPath={handleNavigation} user={user} />
      ) : (
        <Login setCurrentPath={handleNavigation} />
      );
      break;
    case "/register":
      content = user ? (
        // If user is logged in, redirect to appropriate dashboard
        role === "admin" ? <AdminDashboard setCurrentPath={handleNavigation} user={user} /> : <MwananchiDashboard setCurrentPath={handleNavigation} user={user} />
      ) : (
        <Register setCurrentPath={handleNavigation} />
      );
      break;
    case "/reset":
      content = user ? (
        // If user is logged in, redirect to appropriate dashboard
        role === "admin" ? <AdminDashboard setCurrentPath={handleNavigation} user={user} /> : <MwananchiDashboard setCurrentPath={handleNavigation} user={user} />
      ) : (
        <ResetPassword setCurrentPath={handleNavigation} />
      );
      break;
    case "/admin":
      content = user && role === "admin" ? (
        <AdminDashboard setCurrentPath={handleNavigation} user={user} />
      ) : (
        // If not admin or not logged in, redirect to login
        <Login setCurrentPath={handleNavigation} />
      );
      break;
    case "/mwananchi":
      content = user && role === "mwananchi" ? (
        <MwananchiDashboard setCurrentPath={handleNavigation} user={user} />
      ) : (
        // If not mwananchi or not logged in, redirect to login
        <Login setCurrentPath={handleNavigation} />
      );
      break;
    default:
      // Fallback for unknown routes, redirect to home
      content = <Home setCurrentPath={handleNavigation} user={user} role={role} />;
      break;
  }

  return (
    <div className="font-sans antialiased">
      {content}
    </div>
  );
}
