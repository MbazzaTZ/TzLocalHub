import React, { createContext, useContext, useEffect, useState } from 'react';
import { initializeApp } from 'firebase/app';
import { getAuth, onAuthStateChanged, signInWithCustomToken, signInAnonymously } from 'firebase/auth';
import { getFirestore, doc, getDoc } from 'firebase/firestore';

// --- Firebase Initialization ---
// This logic initializes Firebase using a global configuration object.
// In the target environment, a __firebase_config variable is expected to be available.
let app, auth, db;

try {
  const firebaseConfig = typeof __firebase_config !== 'undefined'
    ? JSON.parse(__firebase_config)
    : {};

  // Initialize Firebase services only if config has been successfully loaded.
  if (firebaseConfig.apiKey) {
    app = initializeApp(firebaseConfig);
    auth = getAuth(app);
    db = getFirestore(app);
  } else {
    console.warn("Firebase config not found or is invalid. Firebase services will not be available.");
  }
} catch (error) {
    console.error("Error parsing Firebase config or initializing services:", error);
}
// --- End Firebase Initialization ---

// 1. Create the Authentication Context
const AuthContext = createContext();

// 2. Create a custom hook for easy access to the context
export function useAuth() {
  return useContext(AuthContext);
}

// 3. Create the AuthProvider component
export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const [loading, setLoading] = useState(true);

  // This effect handles the initial authentication process when the app loads.
  useEffect(() => {
    // Do not proceed if Firebase services could not be initialized.
    if (!auth) {
      setLoading(false);
      return;
    }

    // Sign in the user. The environment is expected to provide an auth token.
    // Fallback to anonymous sign-in if no token is available.
    const signInUser = async () => {
      try {
        if (typeof __initial_auth_token !== 'undefined' && __initial_auth_token) {
          await signInWithCustomToken(auth, __initial_auth_token);
        } else {
          await signInAnonymously(auth);
        }
      } catch (error) {
        console.error("Error during initial user sign-in:", error);
        setLoading(false); // Stop loading on sign-in failure.
      }
    };

    signInUser();
  }, []); // The empty dependency array ensures this effect runs only once on mount.


  // This effect sets up a listener for changes in the user's auth state.
  useEffect(() => {
    // Do not set up the listener if Firebase services are not available.
    if (!auth || !db) {
        return;
    }

    // onAuthStateChanged returns an unsubscribe function that we can use for cleanup.
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        // User is signed in. Fetch their user-specific data from Firestore.
        const userDocRef = doc(db, 'users', user.uid);
        const userDocSnap = await getDoc(userDocRef);

        if (userDocSnap.exists()) {
          // If the user document exists, extract and set their role.
          setUserRole(userDocSnap.data().role);
        } else {
          // This can happen if a user is authenticated but their document hasn't been created yet.
          console.warn(`User document not found in Firestore for UID: ${user.uid}`);
          setUserRole(null);
        }
        setCurrentUser(user);
      } else {
        // User is signed out. Clear user data.
        setCurrentUser(null);
        setUserRole(null);
      }
      // The initial auth state has been determined, so we can stop loading.
      setLoading(false);
    });

    // Cleanup: Unsubscribe from the listener when the component unmounts.
    return unsubscribe;
  }, []); // The empty dependency array ensures this effect runs only once.

  // The value object contains the auth data to be shared with descendant components.
  const value = {
    currentUser,
    userRole,
    loading,
  };

  return (
    <AuthContext.Provider value={value}>
      {/* This prevents rendering child components until the initial authentication 
        check is finished, avoiding flicker or rendering protected routes incorrectly.
      */}
      {!loading && children}
    </AuthContext.Provider>
  );
}
