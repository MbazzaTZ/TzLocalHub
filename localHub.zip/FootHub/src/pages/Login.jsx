import React, { useState, useEffect } from 'react';
import { initializeApp } from 'firebase/app';
import { 
    getAuth, 
    onAuthStateChanged, 
    signOut, 
    signInAnonymously, 
    createUserWithEmailAndPassword, 
    signInWithEmailAndPassword,
    GoogleAuthProvider, 
    signInWithPopup,    
    RecaptchaVerifier, // Import RecaptchaVerifier
    signInWithPhoneNumber // Import signInWithPhoneNumber
} from 'firebase/auth';
import { getFirestore, doc, setDoc, serverTimestamp, getDoc } from 'firebase/firestore'; 

// --- Firebase Configuration ---
const firebaseConfig = typeof __firebase_config !== 'undefined' ? JSON.parse(__firebase_config) : {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_AUTH_DOMAIN",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-app-id';

const googleProvider = new GoogleAuthProvider();

// --- Custom Modal Component ---
const Modal = ({ message, onClose }) => {
    return (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl p-6 max-w-sm w-full text-center transform transition-all duration-300 scale-100 opacity-100">
                <p className="text-gray-800 text-lg mb-6">{message}</p>
                <button
                    onClick={onClose}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-lg shadow-md transition duration-200 focus:outline-none focus:ring-4 focus:ring-blue-300"
                >
                    Funga
                </button>
            </div>
        </div>
    );
};

// --- Login Page Component ---
const LoginPage = ({ setPage }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [phoneNumber, setPhoneNumber] = useState(''); // State for phone number input
    const [verificationCode, setVerificationCode] = useState(''); // State for SMS verification code
    const [confirmationResult, setConfirmationResult] = useState(null); // Stores the result of signInWithPhoneNumber
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    // recaptchaVerifier is now managed as a global property or directly used, not state
    // const [recaptchaVerifier, setRecaptchaVerifier] = useState(null); 

    // Initialize reCAPTCHA on component mount
    useEffect(() => {
        // Ensure reCAPTCHA is initialized only once
        if (!window.recaptchaVerifier) {
            window.recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
                'size': 'invisible', // Can be 'invisible' or 'normal'
                'callback': (response) => {
                    // reCAPTCHA solved, allow signInWithPhoneNumber.
                    console.log("reCAPTCHA solved or ready:", response);
                },
                'expired-callback': () => {
                    setError('Uthibitishaji wa reCAPTCHA umeisha muda. Tafadhali jaribu tena.');
                    setIsLoading(false);
                }
            });
            // Render the reCAPTCHA widget
            window.recaptchaVerifier.render().then(() => {
                console.log("reCAPTCHA rendered.");
            }).catch(err => {
                console.error("reCAPTCHA rendering error:", err);
                setError("Kuna tatizo na reCAPTCHA. Tafadhali hakikisha kikoa kimeidhinishwa katika Firebase.");
            });
        }

        // Cleanup function to destroy reCAPTCHA when component unmounts
        return () => {
            if (window.recaptchaVerifier) {
                // window.recaptchaVerifier.clear(); // This method might not exist or be necessary depending on Firebase SDK version
                console.log("reCAPTCHA verifier cleared.");
            }
        };
    }, []); // Empty dependency array ensures this runs once on mount

    // Handles email/password login
    const handleEmailPasswordLogin = async (e) => {
        e.preventDefault();
        setIsLoading(true);
        setError('');
        try {
            await signInWithEmailAndPassword(auth, email, password);
            setPage('home');
        } catch (err) {
            switch (err.code) {
                case 'auth/user-not-found':
                    setError('Mtumiaji mwenye barua pepe hii hajapatikana.');
                    break;
                case 'auth/wrong-password':
                    setError('Nenosiri si sahihi. Tafadhali jaribu tena.');
                    break;
                case 'auth/invalid-credential':
                    setError('Barua pepe au nenosiri si sahihi.');
                    break;
                default:
                    setError('Imeshindwa kuingia. Tafadhali angalia taarifa zako.');
                    break;
            }
            console.error("Login error:", err);
        }
        setIsLoading(false);
    };

    // Handles Google Sign-In
    const handleGoogleSignIn = async () => {
        setIsLoading(true);
        setError('');
        try {
            const result = await signInWithPopup(auth, googleProvider);
            const user = result.user;
            const userDocRef = doc(db, `artifacts/${appId}/public/data/users`, user.uid);
            const userDoc = await getDoc(userDocRef); 
            if (!userDoc.exists()) {
                await setDoc(userDocRef, {
                    uid: user.uid,
                    email: user.email,
                    displayName: user.displayName,
                    photoURL: user.photoURL,
                    role: 'user',
                    createdAt: serverTimestamp()
                });
            }
            setPage('home');
        } catch (err) {
            console.error("Google Sign-In error:", err);
            setError('Imeshindwa kuingia na Google. Tafadhali jaribu tena.');
        }
        setIsLoading(false);
    };

    // Handles sending SMS verification code
    const handleSendVerificationCode = async () => {
        setError('');
        if (!phoneNumber) {
            setError('Tafadhali weka namba ya simu.');
            return;
        }
        setIsLoading(true);
        try {
            // Use the global recaptchaVerifier instance
            const appVerifier = window.recaptchaVerifier;
            if (!appVerifier) {
                setError('reCAPTCHA haijapakia vizuri. Tafadhali jaribu upya au pakia ukurasa upya.');
                setIsLoading(false);
                return;
            }
            const result = await signInWithPhoneNumber(auth, phoneNumber, appVerifier);
            setConfirmationResult(result);
            setError('Nambari ya uthibitisho imetumwa kwa simu yako.');
        } catch (err) {
            console.error("Error sending verification code:", err);
            switch (err.code) {
                case 'auth/invalid-phone-number':
                    setError('Namba ya simu si sahihi. Tafadhali angalia umbizo (mfano: +2557XXXXXXXX).');
                    break;
                case 'auth/too-many-requests':
                    setError('Umejaribu mara nyingi sana. Tafadhali jaribu tena baadaye.');
                    break;
                case 'auth/web-storage-unsupported':
                    setError('Kifaa chako hakitumii uhifadhi wa wavuti, ambao unahitajika kwa reCAPTCHA. Tafadhali tumia kivinjari kingine.');
                    break;
                default:
                    setError('Imeshindwa kutuma nambari ya uthibitisho. Tafadhali jaribu tena. Hakikisha kikoa kimeidhinishwa katika Firebase.');
                    break;
            }
        }
        setIsLoading(false);
    };

    // Handles verifying the SMS code
    const handleVerifyCode = async () => {
        setError('');
        if (!verificationCode) {
            setError('Tafadhali weka nambari ya uthibitisho.');
            return;
        }
        setIsLoading(true);
        try {
            const result = await confirmationResult.confirm(verificationCode);
            const user = result.user;

            // Check if user already exists in Firestore. If not, create a new document.
            const userDocRef = doc(db, `artifacts/${appId}/public/data/users`, user.uid);
            const userDoc = await getDoc(userDocRef);
            if (!userDoc.exists()) {
                await setDoc(userDocRef, {
                    uid: user.uid,
                    phoneNumber: user.phoneNumber, // Store phone number from auth
                    role: 'user',
                    createdAt: serverTimestamp()
                });
            } else {
                // If user exists, update their phone number if it's not already set
                if (!userDoc.data().phoneNumber) {
                    await setDoc(userDocRef, { phoneNumber: user.phoneNumber }, { merge: true });
                }
            }
            setPage('home');
        } catch (err) {
            console.error("Error verifying code:", err);
            switch (err.code) {
                case 'auth/invalid-verification-code':
                    setError('Nambari ya uthibitisho si sahihi. Tafadhali jaribu tena.');
                    break;
                case 'auth/code-expired':
                    setError('Nambari ya uthibitisho imeisha muda. Tafadhali tuma tena.');
                    break;
                default:
                    setError('Imeshindwa kuthibitisha nambari. Tafadhali jaribu tena.');
                    break;
            }
        }
        setIsLoading(false);
    };

    return (
        <div className="bg-white p-8 rounded-xl shadow-2xl w-full max-w-md text-gray-800">
            <h2 className="text-3xl font-bold text-center mb-6">Ingia Kwenye Akaunti</h2>
            {error && <p className="bg-red-100 text-red-700 p-3 rounded-md text-center mb-4">{error}</p>}
            
            {/* Email/Password Login Section */}
            <h3 className="text-xl font-semibold mb-4">Ingia kwa Barua Pepe</h3>
            <form onSubmit={handleEmailPasswordLogin} className="space-y-6 mb-8">
                <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Barua Pepe"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
                <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Nenosiri"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
                <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg shadow-lg transition duration-200 disabled:bg-blue-400"
                >
                    {isLoading ? 'Inaingia...' : 'Ingia'}
                </button>
            </form>

            <div className="relative flex py-5 items-center">
                <div className="flex-grow border-t border-gray-300"></div>
                <span className="flex-shrink mx-4 text-gray-400">AU</span>
                <div className="flex-grow border-t border-gray-300"></div>
            </div>

            {/* Phone Number Login Section */}
            <h3 className="text-xl font-semibold mb-4">Ingia kwa Namba ya Simu</h3>
            <div className="space-y-6 mb-8">
                {!confirmationResult ? (
                    <>
                        <input
                            type="tel"
                            value={phoneNumber}
                            onChange={(e) => setPhoneNumber(e.target.value)}
                            placeholder="Namba ya Simu (Mfano: +2557XXXXXXXX)"
                            required
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                        />
                        <button
                            onClick={handleSendVerificationCode}
                            disabled={isLoading}
                            className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-8 rounded-lg shadow-lg transition duration-200 disabled:bg-purple-400"
                        >
                            {isLoading ? 'Inatuma Nambari...' : 'Tuma Nambari ya Uthibitisho'}
                        </button>
                        {/* reCAPTCHA container - must be present and visible for debugging if needed, but invisible for production */}
                        <div id="recaptcha-container" className="mt-4"></div> 
                    </>
                ) : (
                    <>
                        <input
                            type="text"
                            value={verificationCode}
                            onChange={(e) => setVerificationCode(e.target.value)}
                            placeholder="Weka Nambari ya Uthibitisho (SMS)"
                            required
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                        />
                        <button
                            onClick={handleVerifyCode}
                            disabled={isLoading}
                            className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-8 rounded-lg shadow-lg transition duration-200 disabled:bg-green-400"
                        >
                            {isLoading ? 'Inathibitisha...' : 'Thibitisha Nambari'}
                        </button>
                        <button
                            onClick={() => {
                                setConfirmationResult(null); // Allow user to go back and resend code
                                setVerificationCode(''); // Clear verification code
                                setError(''); // Clear error message
                            }} 
                            disabled={isLoading}
                            className="w-full bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-8 rounded-lg shadow-lg transition duration-200 disabled:bg-gray-400 mt-2"
                        >
                            Tuma Upya Nambari
                        </button>
                    </>
                )}
            </div>

            <div className="relative flex py-5 items-center">
                <div className="flex-grow border-t border-gray-300"></div>
                <span className="flex-shrink mx-4 text-gray-400">AU</span>
                <div className="flex-grow border-t border-gray-300"></div>
            </div>

            {/* Google Sign-In Button */}
            <button
                onClick={handleGoogleSignIn}
                disabled={isLoading}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-8 rounded-lg shadow-lg transition duration-200 disabled:bg-red-400 flex items-center justify-center gap-2 mb-6"
            >
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12.24 10.285V14.4h6.806c-.275 1.764-2.057 5.106-6.806 5.106-4.116 0-7.48-3.37-7.48-7.49S8.124 2.295 12.24 2.295c2.647 0 4.195 1.023 5.195 1.986l3.076-3.076C18.724.295 15.794-.005 12.24-.005c-7.33 0-12.72 5.39-12.72 12.72s5.39 12.72 12.72 12.72c7.09 0 12.29-5.07 12.29-12.29 0-.82-.08-1.48-.18-2.115H12.24z"/>
                </svg>
                {isLoading ? 'Inaingia na Google...' : 'Ingia na Google'}
            </button>
            
            <div className="mt-6 text-center">
                <p className="text-sm text-gray-600">
                    Huna akaunti? <button onClick={() => setPage('register')} className="font-semibold text-blue-600 hover:underline">Jisajili</button>
                </p>
                <button onClick={() => setPage('home')} className="mt-4 text-sm text-gray-500 hover:underline">
                    &larr; Rudi Mwanzo
                </button>
            </div>
        </div>
    );
};

// --- Register Page Component ---
const RegisterPage = ({ setPage }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [mobileNumber, setMobileNumber] = useState(''); 
    const [isAdmin, setIsAdmin] = useState(false); 
    const [dedicatedUserId, setDedicatedUserId] = useState(''); 
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleRegister = async (e) => {
        e.preventDefault();
        if (password !== confirmPassword) {
            setError('Manenosiri hayafanani.');
            return;
        }
        if (isAdmin && !dedicatedUserId.trim()) {
            setError('Tafadhali weka Kitambulisho cha Mtumiaji Maalum kwa msimamizi.');
            return;
        }

        setIsLoading(true);
        setError(''); 
        try {
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            const user = userCredential.user;

            const userData = {
                uid: user.uid,
                email: user.email,
                role: isAdmin ? 'admin' : 'user', 
                createdAt: serverTimestamp(), 
                mobileNumber: mobileNumber 
            };

            if (isAdmin) {
                userData.dedicatedUserId = dedicatedUserId; 
            }

            await setDoc(doc(db, `artifacts/${appId}/public/data/users`, user.uid), userData);

            setPage('home'); 
        } catch (err) {
            switch (err.code) {
                case 'auth/email-already-in-use':
                    setError('Barua pepe hii ishatumika.');
                    break;
                case 'auth/weak-password':
                    setError('Nenosiri ni dhaifu. Linahitaji angalau herufi 6.');
                    break;
                default:
                    setError('Imeshindwa kujisajili. Tafadhali jaribu tena.');
                    break;
            }
            console.error("Registration error:", err);
        }
        setIsLoading(false);
    };

    const handleGoogleSignIn = async () => {
        setIsLoading(true);
        setError('');
        try {
            const result = await signInWithPopup(auth, googleProvider);
            const user = result.user;
            const userDocRef = doc(db, `artifacts/${appId}/public/data/users`, user.uid);
            const userDoc = await getDoc(userDocRef); 
            if (!userDoc.exists()) {
                await setDoc(userDocRef, {
                    uid: user.uid,
                    email: user.email,
                    displayName: user.displayName,
                    photoURL: user.photoURL,
                    role: 'user', 
                    createdAt: serverTimestamp(),
                    mobileNumber: mobileNumber 
                });
            }
            setPage('home'); 
        } catch (err) {
            console.error("Google Sign-In error:", err);
            setError('Imeshindwa kujisajili na Google. Tafadhali jaribu tena.');
        }
        setIsLoading(false);
    };

    return (
        <div className="bg-white p-8 rounded-xl shadow-2xl w-full max-w-md text-gray-800">
            <h2 className="text-3xl font-bold text-center mb-6">Tengeneza Akaunti</h2>
            {error && <p className="bg-red-100 text-red-700 p-3 rounded-md text-center mb-4">{error}</p>}
            <form onSubmit={handleRegister} className="space-y-6">
                <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Barua Pepe"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
                <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Nenosiri"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
                <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Thibitisha Nenosiri"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
                <input
                    type="tel" 
                    value={mobileNumber}
                    onChange={(e) => setMobileNumber(e.target.value)}
                    placeholder="Namba ya Simu (Mfano: +2557XXXXXXXX)"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
                <div className="flex items-center space-x-2">
                    <input
                        type="checkbox"
                        id="isAdmin"
                        checked={isAdmin}
                        onChange={(e) => setIsAdmin(e.target.checked)}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                    <label htmlFor="isAdmin" className="text-gray-700 text-sm">Jisajili kama Msimamizi?</label>
                </div>

                {isAdmin && (
                    <input
                        type="text"
                        value={dedicatedUserId}
                        onChange={(e) => setDedicatedUserId(e.target.value)}
                        placeholder="Kitambulisho cha Mtumiaji Maalum (Mfano: DAR-UBN-GOB-STR-12345)"
                        required={isAdmin} 
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                    />
                )}

                <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-8 rounded-lg shadow-lg transition duration-200 disabled:bg-green-400"
                >
                    {isLoading ? 'Inasajili...' : 'Jisajili'}
                </button>
            </form>
            <div className="mt-6 text-center space-y-4">
                <button
                    onClick={handleGoogleSignIn}
                    disabled={isLoading}
                    className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-8 rounded-lg shadow-lg transition duration-200 disabled:bg-red-400 flex items-center justify-center gap-2"
                >
                    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12.24 10.285V14.4h6.806c-.275 1.764-2.057 5.106-6.806 5.106-4.116 0-7.48-3.37-7.48-7.49S8.124 2.295 12.24 2.295c2.647 0 4.195 1.023 5.195 1.986l3.076-3.076C18.724.295 15.794-.005 12.24-.005c-7.33 0-12.72 5.39-12.72 12.72s5.39 12.72 12.72 12.72c7.09 0 12.29-5.07 12.29-12.29 0-.82-.08-1.48-.18-2.115H12.24z"/>
                    </svg>
                    {isLoading ? 'Inasajili na Google...' : 'Jisajili na Google'}
                </button>
                <p className="text-sm text-gray-600">
                    Unayo akaunti tayari? <button onClick={() => setPage('login')} className="font-semibold text-blue-600 hover:underline">Ingia</button>
                </p>
                <button onClick={() => setPage('home')} className="mt-4 text-sm text-gray-500 hover:underline">
                    &larr; Rudi Mwanzo
                </button>
            </div>
        </div>
    );
};

// --- Home Page Component ---
const HomePage = ({ setPage, handleLogout, currentUser }) => {
    const [showModal, setShowModal] = useState(false); 

    return (
        <div className="bg-white p-8 rounded-xl shadow-2xl text-center max-w-lg w-full transform transition-all duration-300 hover:scale-105">
            <div className="flex justify-center mb-4">
                <img 
                    src="https://placehold.co/120x120/E0E0E0/333333?text=NEMBO" 
                    alt="Portal Logo" 
                    className="h-24 w-24 rounded-full" 
                    onError={(e) => { e.target.onerror = null; e.target.src='https://placehold.co/120x120?text=Nembo'; }}
                />
            </div>

            <h1 className="text-4xl font-extrabold text-gray-800 mb-4">
                Tanzania Local Government Portal
            </h1>
            <p className="text-lg text-gray-600 mb-8">
                Chagua unachohitaji ili kuendelea
            </p>

            <div className="flex flex-col sm:flex-row justify-center items-center gap-6">
                {currentUser && !currentUser.isAnonymous ? (
                    <>
                        <button
                            onClick={() => setShowModal(true)} 
                            className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg shadow-lg transform transition-transform duration-200 hover:scale-105 focus:outline-none focus:ring-4 focus:ring-blue-300"
                        >
                            Nenda Dashibodi
                        </button>
                        <button
                            onClick={handleLogout}
                            className="bg-red-500 hover:bg-red-600 text-white font-bold py-3 px-8 rounded-lg shadow-lg transform transition-transform duration-200 hover:scale-105 focus:outline-none focus:ring-4 focus:ring-red-300"
                        >
                            Toka
                        </button>
                    </>
                ) : (
                    <>
                        <button
                            onClick={() => setPage('login')}
                            className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg shadow-lg transform transition-transform duration-200 hover:scale-105 focus:outline-none focus:ring-4 focus:ring-blue-300"
                        >
                            Ingia
                        </button>
                        <button
                            onClick={() => setPage('register')}
                            className="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-8 rounded-lg shadow-lg transform transition-transform duration-200 hover:scale-105 focus:outline-none focus:ring-4 focus:ring-green-300"
                        >
                            Jisajili
                        </button>
                    </>
                )}
            </div>
            {currentUser && (
                <p className="text-xs text-gray-400 mt-6">
                    Umeingia kama: {currentUser.isAnonymous ? 'Mgeni' : currentUser.email}
                    {currentUser.mobileNumber && ` (${currentUser.mobileNumber})`}
                </p>
            )}

            {showModal && (
                <Modal
                    message="Utaelekezwa kwenye dashibodi yako."
                    onClose={() => setShowModal(false)}
                />
            )}
        </div>
    );
};

// --- Main App Component ---
export default function App() {
    const [page, setPage] = useState('home'); 
    const [currentUser, setCurrentUser] = useState(null);
    const [isLoading, setIsLoading] = useState(true); 

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, async user => { 
            if (user) {
                const userDocRef = doc(db, `artifacts/${appId}/public/data/users`, user.uid);
                const userDoc = await getDoc(userDocRef);
                if (userDoc.exists()) {
                    setCurrentUser({ ...user, ...userDoc.data() });
                } else {
                    setCurrentUser(user);
                }
            } else {
                signInAnonymously(auth).catch(error => {
                    console.error("Anonymous sign-in failed:", error);
                });
            }
            setIsLoading(false); 
        });
        return () => unsubscribe();
    }, []); 

    const handleLogout = async () => {
        try {
            await signOut(auth);
            setPage('home'); 
        } catch (error) {
            console.error("Error logging out:", error.message);
        }
    };

    const renderPage = () => {
        switch (page) {
            case 'login':
                return <LoginPage setPage={setPage} />;
            case 'register':
                return <RegisterPage setPage={setPage} />;
            case 'home':
            default:
                return <HomePage setPage={setPage} handleLogout={handleLogout} currentUser={currentUser} />;
        }
    };
    
    if (isLoading) {
        return (
            <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-500 to-indigo-600">
                <div className="animate-spin rounded-full h-24 w-24 border-t-4 border-b-4 border-white"></div>
            </div>
        )
    }

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-blue-500 to-indigo-600 text-white p-4 font-inter">
            {renderPage()}
        </div>
    );
}
