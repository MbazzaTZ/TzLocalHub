import React, { useState, useEffect, useCallback } from "react";
import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged, signOut } from 'firebase/auth';
import { getFirestore, collection, query, onSnapshot, doc, updateDoc, deleteDoc, addDoc, serverTimestamp, where, getDocs, collectionGroup } from 'firebase/firestore';
import { getStorage, ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";

// --- Firebase Configuration ---
const firebaseConfig = typeof __firebase_config !== 'undefined' ? JSON.parse(__firebase_config) : {
    apiKey: "YOUR_API_KEY", authDomain: "YOUR_AUTH_DOMAIN", projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET", messagingSenderId: "YOUR_MESSAGING_SENDER_ID", appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);
const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-app-id';

// --- Helper Components ---

const ConfirmationModal = ({ isOpen, onClose, onConfirm, title, message, confirmText = "Thibitisha", confirmColor = "red" }) => {
    if (!isOpen) return null;
    const colorClasses = {
        red: "bg-red-600 hover:bg-red-700",
        blue: "bg-blue-600 hover:bg-blue-700",
        green: "bg-green-600 hover:bg-green-700"
    };
    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50">
            <div className="bg-white p-6 rounded-lg shadow-xl max-w-sm w-full mx-4">
                <h3 className="text-xl font-bold text-gray-800 mb-4">{title}</h3>
                <p className="text-gray-600 mb-6">{message}</p>
                <div className="flex justify-end gap-4">
                    <button onClick={onClose} className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-lg transition duration-200">Ghairi</button>
                    <button onClick={onConfirm} className={`text-white font-bold py-2 px-4 rounded-lg transition duration-200 ${colorClasses[confirmColor]}`}>{confirmText}</button>
                </div>
            </div>
        </div>
    );
};

const PlaceholderComponent = ({ title }) => (
    <div className="text-center p-10 border-2 border-dashed border-gray-300 rounded-lg">
        <h3 className="text-xl font-semibold text-gray-500">{title}</h3>
        <p className="text-gray-400 mt-2">Sehemu hii bado inatengenezwa.</p>
    </div>
);

// --- User Form Modal for Add/Edit ---
const UserFormModal = ({ isOpen, onClose, onSave, user }) => {
    const [formData, setFormData] = useState({});
    const [idImage, setIdImage] = useState(null);
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        if (user) {
            setFormData(user);
        } else {
            setFormData({ email: "", role: "user", officeLocation: "", officeId: "", mobileNumber: "", nidaNumber: "" });
        }
        setIdImage(null);
    }, [user, isOpen]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleFileChange = (e) => {
        if (e.target.files[0]) {
            setIdImage(e.target.files[0]);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSaving(true);
        await onSave(formData, idImage);
        setIsSaving(false);
        onClose();
    };

    if (!isOpen) return null;

    const userRoles = ["Admin Kamili", "Admin Halmashauri", "Admin Kata", "Admin Kijiji", "Admin Polisi", "Afya", "Zimamoto", "TANESCO", "DAWASA/RUWASA", "TARURA", "Ustawi wa Jamii", "User"];

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 p-4">
            <div className="bg-white p-6 rounded-lg shadow-xl max-w-lg w-full">
                <h3 className="text-2xl font-bold text-gray-800 mb-6">{user ? "Hariri Mtumiaji" : "Ongeza Mtumiaji Mpya"}</h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <input type="email" name="email" value={formData.email || ""} onChange={handleChange} placeholder="Barua Pepe" required className="w-full p-2 border rounded" />
                        <select name="role" value={formData.role || "user"} onChange={handleChange} className="w-full p-2 border rounded">
                            {userRoles.map(role => <option key={role} value={role.toLowerCase().replace(/ /g, "_")}>{role}</option>)}
                        </select>
                        <input type="text" name="officeLocation" value={formData.officeLocation || ""} onChange={handleChange} placeholder="Eneo la Ofisi (k.m. Goba, Ubungo)" className="w-full p-2 border rounded" />
                        <input type="text" name="officeId" value={formData.officeId || ""} onChange={handleChange} placeholder="Namba ya Utambulisho ya Ofisi" className="w-full p-2 border rounded" />
                        <input type="tel" name="mobileNumber" value={formData.mobileNumber || ""} onChange={handleChange} placeholder="Namba ya Simu" required className="w-full p-2 border rounded" />
                        <input type="text" name="nidaNumber" value={formData.nidaNumber || ""} onChange={handleChange} placeholder="Namba ya NIDA" className="w-full p-2 border rounded" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Picha ya Kitambulisho</label>
                        <input type="file" onChange={handleFileChange} accept="image/*" className="mt-1 w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" />
                        {idImage && <p className="text-xs text-gray-500 mt-1">Umechagua: {idImage.name}</p>}
                        {!idImage && formData.idImageUrl && <a href={formData.idImageUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-500 hover:underline">Tazama Picha ya Sasa</a>}
                    </div>
                    <div className="flex justify-end gap-4 pt-4">
                        <button type="button" onClick={onClose} className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-lg">Ghairi</button>
                        <button type="submit" disabled={isSaving} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg disabled:bg-blue-300">{isSaving ? "Inahifadhi..." : "Hifadhi"}</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

// --- User Management Component ---
const ManageUsers = ({ currentUser }) => {
    const [users, setUsers] = useState([]);
    const [message, setMessage] = useState("");
    const [error, setError] = useState("");
    const [isLoading, setIsLoading] = useState(true);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [userToEdit, setUserToEdit] = useState(null);
    const [userToDelete, setUserToDelete] = useState(null);

    useEffect(() => {
        const usersRef = collection(db, `artifacts/${appId}/public/data/users`);
        const q = query(usersRef);
        const unsubscribe = onSnapshot(q, (querySnapshot) => {
            const usersList = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            setUsers(usersList);
            setIsLoading(false);
        }, (err) => {
            setError("Failed to fetch users. " + err.message);
            setIsLoading(false);
        });
        return () => unsubscribe();
    }, []);

    const handleSaveUser = async (formData, idImage) => {
        setMessage(""); setError("");
        try {
            let idImageUrl = formData.idImageUrl || "";
            if (idImage) {
                const imagePath = `user_ids/${formData.id || Date.now()}/${idImage.name}`;
                const storageRef = ref(storage, imagePath);
                await uploadBytesResumable(storageRef, idImage);
                idImageUrl = await getDownloadURL(storageRef);
            }
            const userData = { ...formData, idImageUrl };
            if (formData.id) {
                const userRef = doc(db, `artifacts/${appId}/public/data/users`, formData.id);
                await updateDoc(userRef, userData);
                setMessage("Mtumiaji amebadilishwa kikamilifu.");
            } else {
                await addDoc(collection(db, `artifacts/${appId}/public/data/users`), { ...userData, createdAt: serverTimestamp() });
                setMessage("Mtumiaji mpya ameongezwa kikamilifu.");
            }
        } catch (err) { setError(`Imeshindwa kuhifadhi mtumiaji: ${err.message}`); }
    };
    
    const openFormModal = (user = null) => { setUserToEdit(user); setIsFormOpen(true); };
    const openDeleteModal = (user) => { setUserToDelete(user); setIsModalOpen(true); };

    const handleDeleteUser = async () => {
        if (!userToDelete) return;
        try {
            await deleteDoc(doc(db, `artifacts/${appId}/public/data/users`, userToDelete.id));
            setMessage(`Mtumiaji ${userToDelete.email} amefutwa.`);
            setIsModalOpen(false);
        } catch (err) { setError(`Imeshindwa kumfuta mtumiaji: ${err.message}`); setIsModalOpen(false); }
    };

    return (
        <div>
            <UserFormModal isOpen={isFormOpen} onClose={() => setIsFormOpen(false)} onSave={handleSaveUser} user={userToEdit} />
            <ConfirmationModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onConfirm={handleDeleteUser} title="Thibitisha Kufuta" message={`Una uhakika unataka kumfuta mtumiaji ${userToDelete?.email}?`} />
            {message && <div className="p-3 mb-4 rounded-md text-center bg-green-100 text-green-700">{message}</div>}
            {error && <div className="p-3 mb-4 rounded-md text-center bg-red-100 text-red-700">{error}</div>}
            {currentUser?.role === 'admin_kamili' && (
                <button onClick={() => openFormModal()} className="mb-4 bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-200 flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" /></svg>
                    Ongeza Mtumiaji Mpya
                </button>
            )}
             <div className="overflow-x-auto bg-white rounded-lg shadow">
                {isLoading ? <div className="p-10 text-center">Inapakia watumiaji...</div> : (
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Barua Pepe</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jukumu</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Eneo la Ofisi</th>
                                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Vitendo</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {users.map((user) => (
                                <tr key={user.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800">{user.email}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 capitalize">{user.role?.replace(/_/g, " ")}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{user.officeLocation}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-4">
                                        <button onClick={() => openFormModal(user)} className="text-blue-600 hover:text-blue-900">Hariri</button>
                                        <button onClick={() => openDeleteModal(user)} className="text-red-600 hover:text-red-900">Futa</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );
};

// --- Verification Queue Component ---
const VerificationQueue = ({ currentUserProfile }) => {
    const [requests, setRequests] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState("");
    const [expandedId, setExpandedId] = useState(null);
    const [actionState, setActionState] = useState({ type: null, request: null, isOpen: false });

    useEffect(() => {
        if (!currentUserProfile) {
            setIsLoading(false);
            return;
        }

        const { role, officeLocation } = currentUserProfile;

        const collectionsToFetch = [
            { name: 'identityRequests', type: 'Ombi la Utambulisho', locationField: 'district' },
            { name: 'permitRequests', type: 'Ombi la Kibali', locationField: 'applicantDistrict' },
            { name: 'registeredCases', type: 'Usajili wa Kesi', locationField: 'district' },
            { name: 'reports', type: 'Taarifa', locationField: 'district' },
        ];

        const unsubscribes = collectionsToFetch.map(coll => {
            const requestsQuery = collectionGroup(db, coll.name);
            let q;

            if (role === 'admin_kamili') {
                q = query(requestsQuery, where("status", "==", "pending"));
            } else if (role === 'admin_halmashauri' && officeLocation) {
                q = query(requestsQuery, where("status", "==", "pending"), where(coll.locationField, "==", officeLocation));
            } else if (role === 'admin_kata' && officeLocation) {
                q = query(requestsQuery, where("status", "==", "pending"), where("ward", "==", officeLocation));
            } else {
                return () => {};
            }

            return onSnapshot(q, (querySnapshot) => {
                const pendingRequests = querySnapshot.docs.map(doc => {
                    const pathParts = doc.ref.path.split('/');
                    const userIdIndex = pathParts.indexOf('users') + 1;
                    const userId = pathParts[userIdIndex];
                    return {
                        id: doc.id,
                        collectionName: coll.name,
                        type: coll.type,
                        userId: userId,
                        ...doc.data()
                    };
                });
                
                setRequests(prevRequests => {
                    const otherRequests = prevRequests.filter(r => r.collectionName !== coll.name);
                    const newRequests = [...otherRequests, ...pendingRequests];
                    newRequests.sort((a, b) => (b.timestamp?.toDate() || 0) - (a.timestamp?.toDate() || 0));
                    return newRequests;
                });
                setIsLoading(false);

            }, (err) => {
                console.error(`Error fetching ${coll.name}:`, err);
                setError(`Imeshindwa kupata maombi ya aina: ${coll.type}. Sababu: ${err.message}`);
                setIsLoading(false);
            });
        });

        return () => unsubscribes.forEach(unsub => unsub());
    }, [currentUserProfile]);

    const handleAction = async () => {
        const { type, request } = actionState;
        if (!type || !request) return;

        const requestRef = doc(db, `artifacts/${appId}/users/${request.userId}/${request.collectionName}`, request.id);
        try {
            await updateDoc(requestRef, { status: type });
            setActionState({ isOpen: false, type: null, request: null });
        } catch (err) {
            setError(`Imeshindwa kutekeleza: ${err.message}`);
        }
    };

    const openActionModal = (type, request) => {
        setActionState({ type, request, isOpen: true });
    };

    const renderDetails = (req) => {
        const Detail = ({ label, value }) => value ? <p><strong className="font-semibold">{label}:</strong> {value}</p> : null;
        return (
            <>
                <Detail label="Jina" value={req.fullName || req.complainantName || req.reporterName} />
                <Detail label="Simu" value={req.phoneNumber || req.complainantPhone} />
                <Detail label="Eneo" value={`${req.district || req.applicantDistrict}, ${req.ward || req.applicantWard}, ${req.street || req.applicantStreet}`} />
                <Detail label="Madhumuni" value={req.purpose} />
                <Detail label="Aina ya Kibali" value={req.permitType} />
                <Detail label="Ada" value={req.fee ? `${Number(req.fee).toLocaleString()} TSh` : null} />
                <Detail label="Aina ya Kesi" value={req.caseType} />
                <Detail label="Mada ya Kesi" value={req.caseSubject} />
                <Detail label="Maelezo" value={req.detailedDescription} />
                {req.applicantImageUrl && <a href={req.applicantImageUrl} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline block mt-2">Tazama Picha ya Mwombaji</a>}
                {req.idImageUrl && <a href={req.idImageUrl} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline block mt-1">Tazama Kitambulisho</a>}
                {req.evidenceUrl && <a href={req.evidenceUrl} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline block mt-1">Tazama Ushahidi</a>}
            </>
        );
    };

    if (isLoading && requests.length === 0) return <div className="p-10 text-center">Inapakia maombi...</div>;
    if (error) return <div className="p-3 mb-4 rounded-md text-center bg-red-100 text-red-700">{error}</div>;

    return (
        <div>
            <ConfirmationModal isOpen={actionState.isOpen} onClose={() => setActionState({ isOpen: false })} onConfirm={handleAction} title={`Thibitisha: ${actionState.type?.charAt(0).toUpperCase() + actionState.type?.slice(1)}`} message={`Una uhakika unataka ${actionState.type} ombi hili?`} confirmText="Ndiyo, Thibitisha" confirmColor={actionState.type === 'approved' ? 'green' : (actionState.type === 'declined' ? 'red' : 'blue')} />
            <div className="space-y-4">
                {requests.length === 0 ? <PlaceholderComponent title="Hakuna Maombi Mapya" /> : requests.map(req => (
                    <div key={req.id} className="bg-white rounded-lg shadow-md border border-gray-200">
                        <div className="p-4 flex justify-between items-center cursor-pointer" onClick={() => setExpandedId(expandedId === req.id ? null : req.id)}>
                            <div>
                                <p className="font-bold text-gray-800">{req.type}</p>
                                <p className="text-sm text-gray-600">Mwombaji: {req.fullName || req.complainantName || req.reporterName || 'Haijulikani'} - Tarehe: {req.timestamp?.toDate().toLocaleDateString()}</p>
                            </div>
                            <svg className={`w-6 h-6 text-gray-500 transform transition-transform ${expandedId === req.id ? 'rotate-180' : ''}`} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" /></svg>
                        </div>
                        {expandedId === req.id && (
                            <div className="border-t p-4 space-y-2">
                                {renderDetails(req)}
                                <div className="flex justify-end gap-2 pt-4">
                                    <button onClick={() => openActionModal('approved', req)} className="bg-green-500 text-white text-sm font-bold py-1 px-3 rounded-lg hover:bg-green-600">Thibitisha</button>
                                    <button onClick={() => openActionModal('declined', req)} className="bg-red-500 text-white text-sm font-bold py-1 px-3 rounded-lg hover:bg-red-600">Kataa</button>
                                    <button onClick={() => openActionModal('escalated', req)} className="bg-yellow-500 text-white text-sm font-bold py-1 px-3 rounded-lg hover:bg-yellow-600">Uchunguzi Zaidi</button>
                                </div>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};


// --- Main Admin Dashboard Component ---
function AdminDashboard() {
    const [activeTab, setActiveTab] = useState('verification');
    const [currentUser, setCurrentUser] = useState(null);
    const [currentUserProfile, setCurrentUserProfile] = useState(null);
    const [isAuthLoading, setIsAuthLoading] = useState(true);

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, user => {
            if (user) {
                setCurrentUser(user);
                const userDocRef = doc(db, `artifacts/${appId}/public/data/users`, user.uid);
                const unsubDoc = onSnapshot(userDocRef, (doc) => {
                    if (doc.exists()) {
                        setCurrentUserProfile({ uid: user.uid, ...doc.data() });
                    } else {
                        setCurrentUserProfile({ uid: user.uid, role: 'admin_kamili', email: user.email || 'Mgeni' }); 
                    }
                    setIsAuthLoading(false);
                });
                return () => unsubDoc();
            } else {
                signInAnonymously(auth).catch(err => console.error("Anonymous login failed:", err));
                setIsAuthLoading(false);
            }
        });
        return unsubscribe;
    }, []);

    const handleLogout = async () => {
        try {
            await signOut(auth);
            setCurrentUser(null); 
            setCurrentUserProfile(null);
        } catch (err) { console.error("Error logging out:", err); }
    };
    
    if(isAuthLoading) {
        return <div className="flex justify-center items-center h-screen"><div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div></div>
    }

    return (
        <div className="min-h-screen bg-gray-100 p-4 sm:p-8">
            <div className="bg-white rounded-xl shadow-lg p-8 max-w-6xl mx-auto">
                <header className="flex justify-between items-center">
                    <div>
                        <h2 className="text-3xl font-bold text-gray-800">Dashibodi ya Msimamizi</h2>
                        <p className="text-sm text-gray-500 mt-1">Umeingia kama: {currentUserProfile?.email || 'Mgeni'} - Jukumu: <span className="font-semibold capitalize">{currentUserProfile?.role?.replace(/_/g, " ")}</span></p>
                    </div>
                    <button onClick={handleLogout} className="bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-600 transition duration-200">Toka</button>
                </header>
                
                <div className="border-b border-gray-200 mt-6">
                    <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                        {currentUserProfile?.role === 'admin_kamili' && (
                            <button onClick={() => setActiveTab('users')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'users' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>Simamia Watumiaji</button>
                        )}
                        <button onClick={() => setActiveTab('verification')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'verification' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>Uthibitisho</button>
                        <button onClick={() => setActiveTab('escalated')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'escalated' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>Kesi Maalum</button>
                    </nav>
                </div>

                <div className="mt-8">
                    {activeTab === 'users' && currentUserProfile?.role === 'admin_kamili' && <ManageUsers currentUser={currentUserProfile} />}
                    {activeTab === 'verification' && <VerificationQueue currentUserProfile={currentUserProfile} />}
                    {activeTab === 'escalated' && <PlaceholderComponent title="Kesi Maalum Zilizoletwa" />}
                </div>
            </div>
        </div>
    );
}

// --- Main App Component ---
export default function App() {
  return <AdminDashboard />;
}
