import React, { useState, useEffect, useCallback } from "react";
import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, collection, query, where, onSnapshot, doc, updateDoc, addDoc, serverTimestamp, getDocs } from 'firebase/firestore';

// --- Firebase Configuration ---
const firebaseConfig = typeof __firebase_config !== 'undefined' ? JSON.parse(__firebase_config) : {
    apiKey: "YOUR_API_KEY", authDomain: "YOUR_AUTH_DOMAIN", projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET", messagingSenderId: "YOUR_MESSAGING_SENDER_ID", appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-app-id';

// --- Custom Hook: useNotifications (Improved) ---
// This hook manages fetching and updating notifications for the current user.
function useNotifications() {
    const [notifications, setNotifications] = useState([]);
    const [unreadCount, setUnreadCount] = useState(0);
    const [userId, setUserId] = useState(null);
    const [isAuthReady, setIsAuthReady] = useState(false);

    // Effect for handling Firebase Authentication
    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, async (user) => {
            if (user) {
                setUserId(user.uid);
            } else {
                try {
                    const token = typeof __initial_auth_token !== 'undefined' ? __initial_auth_token : null;
                    if (token) {
                        await signInWithCustomToken(auth, token);
                    } else {
                        await signInAnonymously(auth);
                    }
                } catch (error) {
                    console.error("Authentication Error:", error);
                }
            }
            setIsAuthReady(true);
        });
        return () => unsubscribe();
    }, []);

    // Effect for fetching notifications in real-time
    useEffect(() => {
        if (!isAuthReady || !userId) {
            setNotifications([]);
            setUnreadCount(0);
            return;
        }

        // --- IMPROVEMENT: Correct collection path for user-specific data ---
        const notificationsRef = collection(db, `artifacts/${appId}/users/${userId}/notifications`);
        const q = query(notificationsRef, where('userId', '==', userId));

        const unsubscribe = onSnapshot(q, (querySnapshot) => {
            const userNotifications = querySnapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data(),
                // Ensure createdAt is a Date object for sorting
                createdAt: doc.data().createdAt?.toDate() 
            }));

            // --- IMPROVEMENT: Client-side sorting instead of Firestore orderBy ---
            // This avoids the need for composite indexes and potential errors.
            userNotifications.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
            
            const unread = userNotifications.filter(n => n.status === 'unread').length;
            setNotifications(userNotifications);
            setUnreadCount(unread);
        }, (error) => {
            console.error("Error fetching notifications:", error);
        });

        return () => unsubscribe();
    }, [isAuthReady, userId]);

    // --- IMPROVEMENT: Function to mark a single notification as read ---
    const markAsRead = useCallback(async (notificationId) => {
        if (!userId) return;
        const notifRef = doc(db, `artifacts/${appId}/users/${userId}/notifications`, notificationId);
        try {
            await updateDoc(notifRef, { status: 'read' });
        } catch (error) {
            console.error("Error updating notification:", error);
        }
    }, [userId]);

    // --- IMPROVEMENT: Function to mark all notifications as read ---
    const markAllAsRead = useCallback(async () => {
        if (!userId || unreadCount === 0) return;
        const notificationsRef = collection(db, `artifacts/${appId}/users/${userId}/notifications`);
        const q = query(notificationsRef, where('status', '==', 'unread'), where('userId', '==', userId));
        
        try {
            const querySnapshot = await getDocs(q);
            querySnapshot.forEach(async (document) => {
                const notifRef = doc(db, `artifacts/${appId}/users/${userId}/notifications`, document.id);
                await updateDoc(notifRef, { status: 'read' });
            });
        } catch (error) {
            console.error("Error marking all as read:", error);
        }
    }, [userId, unreadCount]);

    return { notifications, unreadCount, markAsRead, markAllAsRead, userId, isAuthReady };
}

// --- Helper Component: Notification Item ---
const NotificationItem = ({ notification, onRead }) => {
    const isUnread = notification.status === 'unread';
    const Icon = () => (
        <div className={`w-10 h-10 rounded-full flex-shrink-0 mr-4 flex items-center justify-center ${isUnread ? 'bg-blue-100' : 'bg-gray-100'}`}>
            <svg className={`w-6 h-6 ${isUnread ? 'text-blue-500' : 'text-gray-400'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
        </div>
    );

    return (
        <div 
            onClick={() => onRead(notification.id)}
            className={`flex items-center p-4 border-b border-gray-200 cursor-pointer transition-all duration-300 ${isUnread ? 'bg-white hover:bg-blue-50' : 'bg-gray-50 text-gray-500'}`}
        >
            <Icon />
            <div className="flex-grow">
                <p className={`font-semibold ${isUnread ? 'text-gray-800' : 'text-gray-600'}`}>{notification.title}</p>
                <p className="text-sm">{notification.message}</p>
            </div>
            {isUnread && <div className="w-3 h-3 bg-blue-500 rounded-full ml-4 flex-shrink-0"></div>}
        </div>
    );
};

// --- Main Component: NotificationsPanel ---
function NotificationsPanel() {
    const { notifications, unreadCount, markAsRead, markAllAsRead, userId, isAuthReady } = useNotifications();
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        if (isAuthReady) {
            setIsLoading(false);
        }
    }, [isAuthReady]);
    
    // --- Function to create a mock notification for testing ---
    const createMockNotification = async () => {
        if (!userId) return;
        const notificationsRef = collection(db, `artifacts/${appId}/users/${userId}/notifications`);
        try {
            await addDoc(notificationsRef, {
                userId: userId,
                title: "New Case Registered",
                message: `Case #${Math.floor(1000 + Math.random() * 9000)} has been assigned to you.`,
                status: 'unread',
                createdAt: serverTimestamp()
            });
        } catch (error) {
            console.error("Error creating mock notification:", error);
        }
    };

    if (isLoading) {
        return (
            <div className="flex justify-center items-center h-screen bg-gray-100">
                <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-100 font-sans p-4 sm:p-8">
            <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
                <header className="p-6 border-b border-gray-200 flex justify-between items-center">
                    <h1 className="text-2xl font-bold text-gray-800">Arifa Zako</h1>
                    {unreadCount > 0 && (
                        <span className="bg-blue-500 text-white text-xs font-bold px-3 py-1 rounded-full">{unreadCount} Mpya</span>
                    )}
                </header>
                
                <div className="p-4 flex justify-between items-center border-b border-gray-200">
                     <button 
                        onClick={createMockNotification}
                        className="bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-600 transition duration-200 text-sm"
                    >
                        Tengeneza Arifa (Test)
                    </button>
                    {unreadCount > 0 && (
                        <button 
                            onClick={markAllAsRead}
                            className="text-sm font-semibold text-blue-600 hover:text-blue-800"
                        >
                            Soma Zote
                        </button>
                    )}
                </div>

                <main>
                    {notifications.length > 0 ? (
                        notifications.map(notif => (
                            <NotificationItem key={notif.id} notification={notif} onRead={markAsRead} />
                        ))
                    ) : (
                        <div className="text-center p-12 text-gray-500">
                            <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                                <path vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                            <h3 className="mt-2 text-sm font-semibold text-gray-900">Hakuna arifa</h3>
                            <p className="mt-1 text-sm text-gray-500">Bado hujapokea arifa yoyote.</p>
                        </div>
                    )}
                </main>
            </div>
        </div>
    );
}

// --- Main App Component ---
export default function App() {
  return <NotificationsPanel />;
}
