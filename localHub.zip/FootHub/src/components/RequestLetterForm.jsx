import React, { useState } from 'react';

// Note: The following are mock implementations for demonstration purposes.
// In your actual project, you would import these from your context and service files.
// import { useAuth } from '../context/AuthContext'; 
// import { submitResidenceLetterRequest } from '../services/firebaseService';

/**
 * Mock implementation of the useAuth hook.
 * @returns {{currentUser: {uid: string}}}
 */
const useAuth = () => ({ currentUser: { uid: '12345-test-uid' } });

/**
 * Mock implementation of the Firebase service function.
 * Simulates an API call to submit the form data.
 * @param {string} uid - The user's ID.
 * @param {string} idMethod - The identification method used.
 * @param {object} formData - The data from the form.
 * @param {File} documentFile - The uploaded file.
 * @returns {Promise<void>}
 */
const submitResidenceLetterRequest = (uid, idMethod, formData, documentFile) => {
    return new Promise((resolve, reject) => {
        console.log("Submitting Request:", { uid, idMethod, formData, documentFile });
        // Simulate a network delay
        setTimeout(() => {
            // Simulate a potential error for testing purposes
            if (formData.nin === 'error') {
                reject(new Error("Invalid NIN provided. Please check and try again."));
            } else {
                resolve();
            }
        }, 1500);
    });
};


/**
 * A reusable file input component with improved styling and user feedback.
 * It displays the name of the selected file.
 * @param {{id: string, onChange: Function, label: string, fileName: string}} props
 */
const FileUploadInput = ({ id, onChange, label, fileName }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-gray-700">{label}</label>
        <div className="mt-1">
             <label htmlFor={id} className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                <div className="w-full text-sm text-gray-500 border border-gray-300 rounded-lg p-2 flex items-center">
                    <span className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100">
                        {fileName || 'Choose a file...'}
                    </span>
                </div>
                <input id={id} name={id} type="file" onChange={onChange} required className="sr-only" />
            </label>
        </div>
        {fileName && <p className="text-xs text-gray-500 mt-1">Selected: {fileName}</p>}
    </div>
);


/**
 * The main form component for requesting a residence letter.
 */
export default function RequestLetterForm() {
    const { currentUser } = useAuth();

    // State for the selected ID method, form data, and uploaded file
    const [idMethod, setIdMethod] = useState('NIDA');
    const [formData, setFormData] = useState({});
    const [documentFile, setDocumentFile] = useState(null);

    // State for UI feedback (loading, error, success messages)
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [message, setMessage] = useState('');

    // Handler for text and select input changes
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    // Handler for file input changes
    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setDocumentFile(file);
        }
    };

    // Handler for form submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        // Validation: Ensure a document is uploaded if the method is not NIDA
        if (idMethod !== 'NIDA' && !documentFile) {
            setError('A supporting document is required for this identification method.');
            return;
        }

        setIsLoading(true);
        setError('');
        setMessage('');

        try {
            await submitResidenceLetterRequest(currentUser.uid, idMethod, formData, documentFile);
            setMessage('Your application has been submitted successfully. An officer will review it shortly.');
            
            // IMPROVEMENT: Explicitly reset all relevant state on success
            setFormData({});
            setDocumentFile(null);
            setIdMethod('NIDA'); // Reset the dropdown to default
            e.target.reset(); // Clears file input visually

        } catch (err) {
            setError(`Submission failed: ${err.message}`);
        } finally {
            setIsLoading(false);
        }
    };

    // IMPROVEMENT: Handle case where user is not logged in
    if (!currentUser) {
        return (
            <div className="p-8 bg-white shadow-lg rounded-xl max-w-2xl mx-auto text-center">
                <h2 className="text-xl font-bold text-gray-700">Access Denied</h2>
                <p className="text-gray-600 mt-2">Please log in to request a residence letter.</p>
            </div>
        );
    }
    
    // IMPROVEMENT: Added accessibility (id/htmlFor) and structured fields
    const renderFormFields = () => {
        const fileInputProps = {
            onChange: handleFileChange,
            fileName: documentFile ? documentFile.name : ''
        };

        switch (idMethod) {
            case 'NIDA':
                return (
                    <div>
                        <label htmlFor="nin" className="block text-sm font-medium text-gray-700 mb-1">NIDA Number</label>
                        <input id="nin" type="text" name="nin" placeholder="Enter your 20-digit NIDA NIN" onChange={handleInputChange} required className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" />
                    </div>
                );
            case 'NEC':
                return (
                    <>
                        <div>
                            <label htmlFor="necNumber" className="block text-sm font-medium text-gray-700 mb-1">NEC Number</label>
                            <input id="necNumber" type="text" name="necNumber" placeholder="Enter your NEC Number" onChange={handleInputChange} required className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" />
                        </div>
                        <FileUploadInput id="necFile" label="Upload NEC Card Scan" {...fileInputProps} />
                    </>
                );
            case 'PASSPORT':
                return (
                    <>
                        <div>
                            <label htmlFor="passportNumber" className="block text-sm font-medium text-gray-700 mb-1">Passport Number</label>
                            <input id="passportNumber" type="text" name="passportNumber" placeholder="Enter your Passport Number" onChange={handleInputChange} required className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" />
                        </div>
                        <div>
                            <label htmlFor="countryOfIssue" className="block text-sm font-medium text-gray-700 mb-1">Country of Issue</label>
                            <input id="countryOfIssue" type="text" name="countryOfIssue" placeholder="Country of Issue" onChange={handleInputChange} required className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" />
                        </div>
                        <FileUploadInput id="passportFile" label="Upload Passport Bio-Page Scan" {...fileInputProps} />
                    </>
                );
            case 'BIRTH_CERTIFICATE':
                return (
                    <>
                        <div>
                            <label htmlFor="birthCertNumber" className="block text-sm font-medium text-gray-700 mb-1">Birth Certificate Number</label>
                            <input id="birthCertNumber" type="text" name="birthCertNumber" placeholder="Enter your Birth Certificate Number" onChange={handleInputChange} required className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" />
                        </div>
                        <FileUploadInput id="birthCertFile" label="Upload Birth Certificate Scan" {...fileInputProps} />
                    </>
                );
            case 'STUDENT':
                return (
                    <>
                        <div>
                            <label htmlFor="studentLevel" className="block text-sm font-medium text-gray-700 mb-1">Student Level</label>
                            <select id="studentLevel" name="studentLevel" onChange={handleInputChange} required className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500">
                                <option value="">-- Select Level --</option>
                                <option value="STANDARD_7">Standard 7</option>
                                <option value="FORM_4">Form 4</option>
                                <option value="FORM_6">Form 6</option>
                            </select>
                        </div>
                        <div>
                            <label htmlFor="schoolName" className="block text-sm font-medium text-gray-700 mb-1">School Name</label>
                            <input id="schoolName" type="text" name="schoolName" placeholder="School Name" onChange={handleInputChange} required className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" />
                        </div>
                        <div>
                            <label htmlFor="examNumber" className="block text-sm font-medium text-gray-700 mb-1">Exam / Registration Number</label>
                            <input id="examNumber" type="text" name="examNumber" placeholder="Exam / Registration Number" onChange={handleInputChange} required className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" />
                        </div>
                        <FileUploadInput id="studentFile" label="Upload Student ID / Certificate Scan" {...fileInputProps} />
                    </>
                );
            default:
                return null;
        }
    };

    return (
        <div className="p-8 bg-white shadow-lg rounded-xl max-w-2xl mx-auto font-sans">
            <div className="text-center mb-6">
                <h2 className="text-2xl font-bold text-gray-800">Ombi la Barua ya Utambulisho wa Makazi</h2>
                <p className="text-gray-600">Jaza fomu hii ili kupata barua ya utambulisho wa makazi.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                    <label htmlFor="idMethod" className="block text-sm font-medium text-gray-700 mb-1">Chagua Aina ya Utambulisho (Select ID Type)</label>
                    <select 
                        id="idMethod" 
                        value={idMethod} 
                        onChange={(e) => { 
                            setIdMethod(e.target.value); 
                            setDocumentFile(null); // Reset file on type change
                            setError(''); // Clear previous errors
                        }} 
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500"
                    >
                        <option value="NIDA">NIDA (National ID)</option>
                        <option value="NEC">NEC (Voter's ID)</option>
                        <option value="PASSPORT">Passport</option>
                        <option value="BIRTH_CERTIFICATE">Birth Certificate</option>
                        <option value="STUDENT">Student ID</option>
                    </select>
                </div>

                {renderFormFields()}

                <button type="submit" disabled={isLoading} className="w-full flex justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg shadow-md transition-colors duration-300 disabled:bg-gray-400 disabled:cursor-not-allowed">
                    {isLoading ? (
                        <>
                            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Inatuma...
                        </>
                    ) : 'Tuma Ombi (Submit Application)'}
                </button>

                {message && <p className="mt-4 text-center text-green-600 font-semibold bg-green-50 p-3 rounded-lg">{message}</p>}
                {error && <p className="mt-4 text-center text-red-600 font-semibold bg-red-50 p-3 rounded-lg">{error}</p>}
            </form>
        </div>
    );
}
