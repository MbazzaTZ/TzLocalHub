import React, { useState, useEffect, useCallback } from 'react';
import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, onAuthStateChanged, signInWithCustomToken } from 'firebase/auth';
import { 
    getFirestore, 
    collection, 
    query, 
    where, 
    onSnapshot, 
    doc, 
    updateDoc, 
    addDoc, 
    serverTimestamp,
    Timestamp
} from 'firebase/firestore';

// --- Helper Components ---

// Simple loading spinner component
const Spinner = () => (
    <div className="flex justify-center items-center p-8">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
    </div>
);

// Error message component
const ErrorDisplay = ({ message }) => (
    <div className="text-center p-8 bg-red-100 text-red-700 rounded-lg">
        <p className="font-bold">An Error Occurred</p>
        <p>{message}</p>
    </div>
);

// Main Application Component
export default function App() {
    // --- Firebase State ---
    const [db, setDb] = useState(null);
    const [auth, setAuth] = useState(null);
    const [userId, setUserId] = useState(null);
    const [isAuthReady, setIsAuthReady] = useState(false);
    
    // --- App State ---
    const [escalatedRequests, setEscalatedRequests] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState("");

    // --- Modal State ---
    const [isResolveModalOpen, setIsResolveModalOpen] = useState(false);
    const [isEscalateModalOpen, setIsEscalateModalOpen] = useState(false);
    const [selectedRequest, setSelectedRequest] = useState(null);
    const [resolutionNotes, setResolutionNotes] = useState("");
    const [escalationNotes, setEscalationNotes] = useState("");
    const [escalationType, setEscalationType] = useState("Document Verification");
    const [requiredFiles, setRequiredFiles] = useState("");
    const [modalError, setModalError] = useState("");

    // --- App ID for Firestore path ---
    const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-escalation-app';

    // Effect for Firebase Initialization and Authentication
    useEffect(() => {
        try {
            const firebaseConfig = JSON.parse(typeof __firebase_config !== 'undefined' ? __firebase_config : '{}');
            const app = initializeApp(firebaseConfig);
            const authInstance = getAuth(app);
            const dbInstance = getFirestore(app);
            
            setDb(dbInstance);
            setAuth(authInstance);

            const unsubscribe = onAuthStateChanged(authInstance, async (user) => {
                if (user) {
                    setUserId(user.uid);
                } else {
                    try {
                        if (typeof __initial_auth_token !== 'undefined' && __initial_auth_token) {
                            await signInWithCustomToken(authInstance, __initial_auth_token);
                        } else {
                            await signInAnonymously(authInstance);
                        }
                    } catch (authError) {
                        console.error("Authentication Error:", authError);
                        setError("Failed to authenticate. Please refresh the page.");
                    }
                }
                setIsAuthReady(true);
            });
            return () => unsubscribe();
        } catch (e) {
            console.error("Firebase initialization failed:", e);
            setError("Could not connect to the database. Please check the configuration.");
            setIsLoading(false);
        }
    }, [appId]);

    // Effect for fetching escalated requests from Firestore
    useEffect(() => {
        if (!isAuthReady || !db) return;

        setIsLoading(true);
        const requestsRef = collection(db, "artifacts", appId, "public", "data", "letter_requests");
        const q = query(requestsRef, where("status", "==", "escalated"));

        const unsubscribe = onSnapshot(q, (querySnapshot) => {
            const requests = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            requests.sort((a, b) => {
                const timeA = a.escalation?.escalatedAt?.toDate() || 0;
                const timeB = b.escalation?.escalatedAt?.toDate() || 0;
                return timeB - timeA;
            });
            setEscalatedRequests(requests);
            setIsLoading(false);
            setError("");
        }, (err) => {
            console.error("Firestore Snapshot Error:", err);
            setError("Failed to fetch escalated requests. You might need to create a Firestore index.");
            setIsLoading(false);
        });

        return () => unsubscribe();
    }, [isAuthReady, db, appId]);
    
    // --- Service Functions ---
    const resolveRequest = async (requestId, newStatus, notes) => {
        if (!db || !userId) throw new Error("Database not connected or user not authenticated.");
        const requestDocRef = doc(db, "artifacts", appId, "public", "data", "letter_requests", requestId);
        await updateDoc(requestDocRef, {
            status: newStatus,
            "resolution.resolvedBy": userId,
            "resolution.resolvedAt": serverTimestamp(),
            "resolution.notes": notes,
        });
    };

    const escalateToLocalGovt = async (requestId, type, notes, files) => {
        if (!db || !userId) throw new Error("Database not connected or user not authenticated.");
        const requestDocRef = doc(db, "artifacts", appId, "public", "data", "letter_requests", requestId);
        
        const localGovtEscalationData = {
            escalatedBy: userId,
            escalatedAt: serverTimestamp(),
            type: type,
            notes: notes,
        };

        if (type === 'Request More Files' && files) {
            localGovtEscalationData.requiredFiles = files;
        }

        await updateDoc(requestDocRef, {
            "escalation.status": 'pending_local_govt',
            "escalation.localGovtEscalation": localGovtEscalationData,
        });
    };

    // --- Modal Handlers ---
    const handleOpenResolveModal = (request) => {
        setSelectedRequest(request);
        setIsResolveModalOpen(true);
        setResolutionNotes("");
        setModalError("");
    };

    const handleOpenEscalateModal = (request) => {
        setSelectedRequest(request);
        setIsEscalateModalOpen(true);
        setEscalationNotes("");
        setEscalationType("Document Verification");
        setRequiredFiles("");
        setModalError("");
    };

    const handleCloseModals = () => {
        setIsResolveModalOpen(false);
        setIsEscalateModalOpen(false);
        setSelectedRequest(null);
    };

    const handleResolve = async (newStatus) => {
        if (!selectedRequest || !resolutionNotes.trim()) {
            setModalError("Resolution notes are required to proceed.");
            return;
        }
        try {
            await resolveRequest(selectedRequest.id, newStatus, resolutionNotes);
            handleCloseModals();
        } catch (err) {
            console.error("Resolution Error:", err);
            setModalError(err.message || "An unexpected error occurred.");
        }
    };

    const handleConfirmEscalate = async () => {
        if (!selectedRequest || !escalationNotes.trim()) {
            setModalError("Escalation notes for the next department are required.");
            return;
        }
        if (escalationType === 'Request More Files' && !requiredFiles.trim()) {
            setModalError("Please specify which files are required.");
            return;
        }
        try {
            await escalateToLocalGovt(selectedRequest.id, escalationType, escalationNotes, requiredFiles);
            handleCloseModals();
        } catch (err) {
            console.error("Escalation Error:", err);
            setModalError(err.message || "An unexpected error occurred.");
        }
    };
    
    // --- Test Data Handler ---
    const addTestData = async () => {
        if (!db || !userId) return;
        const requestsRef = collection(db, "artifacts", appId, "public", "data", "letter_requests");
        try {
            await addDoc(requestsRef, {
                userId: `user_${Math.random().toString(36).substr(2, 9)}`,
                status: 'escalated',
                escalation: {
                    escalatedBy: userId,
                    escalatedAt: Timestamp.now(),
                    notes: "Applicant's document seems suspicious. Initial check required.",
                    status: 'pending_review'
                },
                createdAt: serverTimestamp()
            });
        } catch (e) {
            console.error("Error adding test data:", e);
            setError("Could not add test data.");
        }
    };

    // --- Render Logic ---
    if (isLoading) return <Spinner />;
    if (error) return <ErrorDisplay message={error} />;

    const renderStatusBadge = (status) => {
        const text = status?.replace('pending_', '').replace('_', ' ').toUpperCase() || 'N/A';
        const colorClass = status === 'pending_local_govt' ? 'bg-purple-100 text-purple-800' : 'bg-orange-100 text-orange-800';
        return <span className={`px-2 py-1 text-xs font-semibold rounded-full ${colorClass}`}>{text}</span>;
    };

    return (
        <div className="p-4 sm:p-6 bg-gray-50 min-h-screen font-sans">
            <div className="max-w-7xl mx-auto">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-800">Escalated Application Tracker</h1>
                        <p className="text-sm text-gray-500 mt-1">Your Admin ID: <span className="font-mono bg-gray-200 px-1 rounded">{userId || '...'}</span></p>
                    </div>
                    <button onClick={addTestData} disabled={!isAuthReady} className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg transition-colors disabled:bg-gray-400">
                        Add Test Escalation
                    </button>
                </div>
                
                {escalatedRequests.length === 0 ? (
                    <div className="text-center py-16 bg-white shadow-md rounded-lg">
                        <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                        <h3 className="mt-2 text-sm font-medium text-gray-900">All Clear!</h3>
                        <p className="mt-1 text-sm text-gray-500">No applications are currently escalated.</p>
                    </div>
                ) : (
                    <div className="bg-white shadow-md rounded-lg overflow-x-auto">
                        <table className="min-w-full leading-normal">
                            <thead>
                                <tr className="bg-gray-100 text-left text-gray-600 uppercase text-sm">
                                    <th className="py-3 px-6">Current Status</th>
                                    <th className="py-3 px-6">Last Update</th>
                                    <th className="py-3 px-6">Applicant User ID</th>
                                    <th className="py-3 px-6">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="text-gray-700">
                                {escalatedRequests.map(req => (
                                    <tr key={req.id} className="border-b border-gray-200 hover:bg-gray-50">
                                        <td className="py-4 px-6">{renderStatusBadge(req.escalation?.status)}</td>
                                        <td className="py-4 px-6 text-sm">{(req.escalation?.localGovtEscalation?.escalatedAt || req.escalation?.escalatedAt)?.toDate().toLocaleString() || 'No Date'}</td>
                                        <td className="py-4 px-6 font-mono text-xs">{req.userId}</td>
                                        <td className="py-4 px-6 space-x-2">
                                            <button onClick={() => handleOpenResolveModal(req)} className="bg-green-500 hover:bg-green-600 text-white font-bold py-1 px-3 rounded-lg text-xs transition-colors">Resolve</button>
                                            {req.escalation?.status === 'pending_review' && (
                                                <button onClick={() => handleOpenEscalateModal(req)} className="bg-purple-500 hover:bg-purple-600 text-white font-bold py-1 px-3 rounded-lg text-xs transition-colors">Escalate</button>
                                            )}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            {/* Resolution Modal */}
            {isResolveModalOpen && selectedRequest && (
                <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4">
                    <div className="bg-white rounded-lg shadow-2xl p-6 max-w-2xl w-full">
                        <h3 className="text-xl font-bold mb-4">Resolve Escalated Application</h3>
                        <div className="space-y-4 text-sm">
                            <div className="p-3 bg-orange-50 rounded-md border border-orange-200">
                                <h4 className="font-semibold text-orange-800">Original Escalation Notes</h4>
                                <p className="italic mt-1">"{selectedRequest.escalation?.notes}"</p>
                            </div>
                            {selectedRequest.escalation?.localGovtEscalation && (
                                <div className="p-3 bg-purple-50 rounded-md border border-purple-200">
                                    <h4 className="font-semibold text-purple-800">Local Govt. Dept. Escalation Details</h4>
                                    <p><strong className="font-medium">Type:</strong> {selectedRequest.escalation.localGovtEscalation.type}</p>
                                    {selectedRequest.escalation.localGovtEscalation.requiredFiles && (
                                        <p><strong className="font-medium">Files Requested:</strong> {selectedRequest.escalation.localGovtEscalation.requiredFiles}</p>
                                    )}
                                    <p className="italic mt-1">"{selectedRequest.escalation.localGovtEscalation.notes}"</p>
                                </div>
                            )}
                            <div>
                                <label htmlFor="resolutionNotes" className="font-semibold block mb-1">Final Resolution Notes</label>
                                <textarea id="resolutionNotes" value={resolutionNotes} onChange={(e) => setResolutionNotes(e.target.value)} className="w-full p-2 border rounded-md" rows="3" placeholder="Enter final decision notes..."></textarea>
                                {modalError && <p className="text-red-500 text-xs mt-1">{modalError}</p>}
                            </div>
                        </div>
                        <div className="flex justify-end mt-6 space-x-3">
                            <button onClick={handleCloseModals} className="px-4 py-2 bg-gray-300 rounded-lg font-semibold">Cancel</button>
                            <button onClick={() => handleResolve('rejected')} className="px-4 py-2 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600">Reject Application</button>
                            <button onClick={() => handleResolve('approved')} className="px-4 py-2 bg-green-500 text-white rounded-lg font-semibold hover:bg-green-600">Approve Application</button>
                        </div>
                    </div>
                </div>
            )}

            {/* Further Escalation Modal */}
            {isEscalateModalOpen && selectedRequest && (
                <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4">
                    <div className="bg-white rounded-lg shadow-2xl p-6 max-w-2xl w-full">
                        <h3 className="text-xl font-bold mb-4">Escalate to Local Government Dept.</h3>
                        <div className="space-y-4 text-sm">
                            <div>
                                <label htmlFor="escalationType" className="font-semibold block mb-1">Escalation Type</label>
                                <select 
                                    id="escalationType" 
                                    value={escalationType} 
                                    onChange={(e) => setEscalationType(e.target.value)}
                                    className="w-full p-2 border rounded-md bg-white"
                                >
                                    <option>Document Verification</option>
                                    <option>Request More Files</option>
                                    <option>Policy Clarification</option>
                                    <option>Other</option>
                                </select>
                            </div>
                            
                            {escalationType === 'Request More Files' && (
                                <div>
                                    <label htmlFor="requiredFiles" className="font-semibold block mb-1">Files to Request</label>
                                    <textarea id="requiredFiles" value={requiredFiles} onChange={(e) => setRequiredFiles(e.target.value)} className="w-full p-2 border rounded-md" rows="2" placeholder="e.g., Certified copy of birth certificate, proof of residence..."></textarea>
                                </div>
                            )}

                            <div>
                                <label htmlFor="escalationNotes" className="font-semibold block mb-1">Notes for Local Govt. Dept.</label>
                                <textarea id="escalationNotes" value={escalationNotes} onChange={(e) => setEscalationNotes(e.target.value)} className="w-full p-2 border rounded-md" rows="3" placeholder="Explain why this needs local government review..."></textarea>
                                {modalError && <p className="text-red-500 text-xs mt-1">{modalError}</p>}
                            </div>
                        </div>
                        <div className="flex justify-end mt-6 space-x-3">
                            <button onClick={handleCloseModals} className="px-4 py-2 bg-gray-300 rounded-lg font-semibold">Cancel</button>
                            <button onClick={handleConfirmEscalate} className="px-4 py-2 bg-purple-500 text-white rounded-lg font-semibold hover:bg-purple-600">Confirm Escalation</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
