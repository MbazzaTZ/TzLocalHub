import React, { useState, useEffect } from 'react';
import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, onAuthStateChanged, signInWithCustomToken } from 'firebase/auth';
import { 
    getFirestore, 
    collection, 
    query, 
    where, 
    onSnapshot, 
    doc, 
    updateDoc, 
    addDoc, 
    serverTimestamp,
    Timestamp
} from 'firebase/firestore';

// --- PDF Generation Service ---
const generateResidenceLetterPDF = (request) => {
    if (!window.jspdf) {
        alert("Error: PDF generation library (jsPDF) is not available. Please refresh the page or check the script imports.");
        console.error("jsPDF is not loaded on the window object.");
        return;
    }
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const { applicant, payment, id, userId } = request;

    const pageHeight = doc.internal.pageSize.height || doc.internal.pageSize.getHeight();
    const pageWidth = doc.internal.pageSize.width || doc.internal.pageSize.getWidth();
    
    doc.setFontSize(20);
    doc.text("🇹🇿", 20, 25); 
    doc.setFont("helvetica", "bold");
    doc.setFontSize(14);
    doc.text("UNITED REPUBLIC OF TANZANIA", pageWidth / 2, 20, { align: "center" });
    doc.setFontSize(12);
    doc.text("LOCAL GOVERNMENT AUTHORITY", pageWidth / 2, 28, { align: "center" });
    doc.setLineWidth(0.5);
    doc.line(20, 35, pageWidth - 20, 35);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(11);
    const today = new Date();
    doc.text(today.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }), pageWidth - 20, 45, { align: "right" });

    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.text("LETTER OF RESIDENCE CONFIRMATION", pageWidth / 2, 60, { align: "center" });
    doc.setLineWidth(0.2);
    doc.line(pageWidth / 2 - 40, 61, pageWidth / 2 + 40, 61);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(11);
    let yPosition = 80;
    const bodyText = `This letter is to certify that the individual detailed below is a known resident of the address provided within our jurisdiction. This confirmation is issued based on the information submitted and verified through our office.`;
    const splitBody = doc.splitTextToSize(bodyText, pageWidth - 40);
    doc.text(splitBody, 20, yPosition);
    yPosition += (splitBody.length * 7) + 10;

    doc.setFont("helvetica", "bold");
    doc.text("Applicant Details:", 20, yPosition);
    yPosition += 8;
    doc.setFont("helvetica", "normal");
    doc.text(`Full Name:`, 25, yPosition);
    doc.setFont("courier", "normal");
    doc.text(`${applicant.fullName}`, 70, yPosition);
    yPosition += 7;
    doc.setFont("helvetica", "normal");
    doc.text(`NIDA Number:`, 25, yPosition);
    doc.setFont("courier", "normal");
    doc.text(`${applicant.nidaNumber}`, 70, yPosition);
    yPosition += 7;
    doc.setFont("helvetica", "normal");
    doc.text(`Address:`, 25, yPosition);
    doc.setFont("courier", "normal");
    doc.text(`${applicant.currentAddress}`, 70, yPosition);
    yPosition += 10;
    doc.setFont("helvetica", "normal");
    doc.text(`Control Number:`, 25, yPosition);
    doc.setFont("courier", "normal");
    doc.text(`${payment.controlNumber}`, 70, yPosition);
    yPosition += 15;

    const verificationUrl = `https://example.com/verify?id=${id}`;
    const qrCodeElement = document.createElement('div');
    if (window.QRCode) {
        new QRCode(qrCodeElement, {
            text: verificationUrl,
            width: 40,
            height: 40,
        });
    }
    
    setTimeout(() => {
        const qrCodeImage = qrCodeElement.querySelector('img')?.src;
        if (qrCodeImage) {
            doc.addImage(qrCodeImage, 'PNG', pageWidth - 65, yPosition, 40, 40);
        }

        const closingText = `This letter is valid for official purposes only. Its authenticity can be verified by scanning the QR code.`;
        const splitClosing = doc.splitTextToSize(closingText, pageWidth - 90);
        doc.setFont("helvetica", "italic");
        doc.text(splitClosing, 20, yPosition + 10);
        yPosition += 30;

        doc.setFont("cursive", "normal");
        doc.setFontSize(20);
        doc.text("J. Mwendaji", 20, yPosition);
        yPosition += 5;

        doc.saveGraphicsState();
        doc.setDrawColor(0, 128, 0);
        doc.setLineWidth(1);
        doc.setTextColor(0, 128, 0);
        doc.setFont("helvetica", "bold");
        doc.setFontSize(18);
        doc.translate(70, yPosition - 5);
        doc.rotate(-15);
        doc.rect(0, 0, 40, 15, 'S');
        doc.text("APPROVED", 2, 11);
        doc.restoreGraphicsState();
        
        yPosition += 15;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(11);
        doc.line(20, yPosition, 80, yPosition);
        yPosition += 5;
        doc.text("Authorised Officer", 20, yPosition);
        doc.text("Local Government Office", 20, yPosition + 5);

        doc.setLineWidth(0.5);
        doc.line(20, pageHeight - 20, pageWidth - 20, pageHeight - 20);
        doc.setFontSize(8);
        doc.text(`Doc ID: ${id} | User ID: ${userId}`, 20, pageHeight - 15);
        doc.text(`Generated on: ${new Date().toLocaleString()}`, pageWidth - 20, pageHeight - 15, { align: "right" });

        doc.save(`Residence_Letter_${applicant.fullName.replace(/\s/g, '_')}.pdf`);
    }, 500);
};


// --- Helper Components ---

const Spinner = () => (
    <div className="flex justify-center items-center p-8">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
    </div>
);

const ErrorDisplay = ({ message }) => (
    <div className="text-center p-8 bg-red-100 text-red-700 rounded-lg">
        <p className="font-bold">An Error Occurred</p>
        <p>{message}</p>
    </div>
);

const NotificationBell = ({ db, userId }) => {
    const [notifications, setNotifications] = useState([]);
    const [isOpen, setIsOpen] = useState(false);
    const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-escalation-app';

    useEffect(() => {
        if (!db || !userId) return;

        const notificationsRef = collection(db, "artifacts", appId, "public", "data", "notifications");
        const q = query(notificationsRef, where("userId", "==", userId));

        const unsubscribe = onSnapshot(q, (querySnapshot) => {
            const notifs = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            notifs.sort((a, b) => (b.createdAt?.toDate() || 0) - (a.createdAt?.toDate() || 0));
            setNotifications(notifs);
        });

        return () => unsubscribe();
    }, [db, userId, appId]);

    const unreadCount = notifications.filter(n => n.status === 'unread').length;

    const handleToggle = async () => {
        setIsOpen(!isOpen);
        if (!isOpen && unreadCount > 0) {
            for (const notification of notifications) {
                if (notification.status === 'unread') {
                    const notificationRef = doc(db, "artifacts", appId, "public", "data", "notifications", notification.id);
                    await updateDoc(notificationRef, { status: 'read' });
                }
            }
        }
    };

    return (
        <div className="relative">
            <button onClick={handleToggle} className="relative">
                <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6 6 0 10-12 0v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
                {unreadCount > 0 && (
                    <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-red-100 bg-red-600 rounded-full">
                        {unreadCount}
                    </span>
                )}
            </button>
            {isOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-xl overflow-hidden z-20">
                    <div className="py-2 px-4 font-bold border-b">Notifications</div>
                    {notifications.length > 0 ? (
                        <div className="max-h-96 overflow-y-auto">
                            {notifications.map(n => (
                                <div key={n.id} className={`p-4 border-b hover:bg-gray-100 ${n.status === 'unread' ? 'bg-blue-50' : ''}`}>
                                    <p className="text-sm text-gray-700">{n.message}</p>
                                    <p className="text-xs text-gray-500 mt-1">
                                        {new Date(n.createdAt?.toDate()).toLocaleString()}
                                    </p>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <p className="p-4 text-sm text-gray-500">No notifications yet.</p>
                    )}
                </div>
            )}
        </div>
    );
};


// --- Main Application Component ---
export default function App() {
    // --- Firebase State ---
    const [db, setDb] = useState(null);
    const [auth, setAuth] = useState(null);
    const [userId, setUserId] = useState(null);
    const [isAuthReady, setIsAuthReady] = useState(false);
    
    // --- App State ---
    const [pendingRequests, setPendingRequests] = useState([]);
    const [processedRequests, setProcessedRequests] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState("");
    const [activeTab, setActiveTab] = useState('pending');
    const [searchTerm, setSearchTerm] = useState('');
    const [userRole, setUserRole] = useState('admin'); // 'admin', 'approver', 'reviewer'

    // --- Modal State ---
    const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
    const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
    const [isRejectionModalOpen, setIsRejectionModalOpen] = useState(false);
    const [isLetterModalOpen, setIsLetterModalOpen] = useState(false);
    const [selectedRequest, setSelectedRequest] = useState(null);
    const [modalError, setModalError] = useState("");
    
    // --- Verification State ---
    const [nidaVerificationStatus, setNidaVerificationStatus] = useState('idle');
    
    // --- Payment & Fee State ---
    const [paymentControlNumber, setPaymentControlNumber] = useState("");
    const FEE_OPTIONS = {
        "Standard": 10000,
        "Urgent": 25000,
    };
    
    // --- Escalation & Rejection Form State ---
    const [showEscalateForm, setShowEscalateForm] = useState(false);
    const [escalateTo, setEscalateTo] = useState('RITA');
    const [escalationNotes, setEscalationNotes] = useState("");
    const [rejectionReason, setRejectionReason] = useState("");
    const [rejectionNotes, setRejectionNotes] = useState("");

    // --- App ID for Firestore path ---
    const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-escalation-app';

    // Effect for Firebase Initialization and Authentication
    useEffect(() => {
        try {
            const firebaseConfig = JSON.parse(typeof __firebase_config !== 'undefined' ? __firebase_config : '{}');
            const app = initializeApp(firebaseConfig);
            const authInstance = getAuth(app);
            const dbInstance = getFirestore(app);
            
            setDb(dbInstance);
            setAuth(authInstance);

            const unsubscribe = onAuthStateChanged(authInstance, async (user) => {
                if (user) {
                    setUserId(user.uid);
                } else {
                    try {
                        if (typeof __initial_auth_token !== 'undefined' && __initial_auth_token) {
                            await signInWithCustomToken(authInstance, __initial_auth_token);
                        } else {
                            await signInAnonymously(authInstance);
                        }
                    } catch (authError) {
                        console.error("Authentication Error:", authError);
                        setError("Failed to authenticate. Please refresh the page.");
                    }
                }
                setIsAuthReady(true);
            });
            return () => unsubscribe();
        } catch (e) {
            console.error("Firebase initialization failed:", e);
            setError("Could not connect to the database. Please check the configuration.");
            setIsLoading(false);
        }
    }, [appId]);

    // Effect for fetching requests
    useEffect(() => {
        if (!isAuthReady || !db) return;

        setIsLoading(true);
        const requestsRef = collection(db, "artifacts", appId, "public", "data", "letter_requests");
        
        const unsubscribe = onSnapshot(query(requestsRef), (querySnapshot) => {
            const allRequests = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            
            const pending = allRequests.filter(r => r.status === 'pending_review');
            const processed = allRequests.filter(r => r.status !== 'pending_review');

            pending.sort((a, b) => (a.createdAt?.toDate() || 0) - (b.createdAt?.toDate() || 0));
            processed.sort((a, b) => (b.resolvedAt?.toDate() || b.createdAt?.toDate() || 0) - (a.resolvedAt?.toDate() || a.createdAt?.toDate() || 0));

            setPendingRequests(pending);
            setProcessedRequests(processed);
            setIsLoading(false);
            setError("");
        }, (err) => {
            console.error("Firestore Snapshot Error:", err);
            setError("Failed to fetch requests.");
            setIsLoading(false);
        });

        return () => unsubscribe();
    }, [isAuthReady, db, appId]);
    
    // --- Service Functions ---
    const createNotification = async (targetUserId, message) => {
        if (!db) return;
        await addDoc(collection(db, "artifacts", appId, "public", "data", "notifications"), {
            userId: targetUserId,
            message,
            status: 'unread',
            createdAt: serverTimestamp(),
        });
    };
    
    const updateRequestStatus = async (requestId, newStatus, details = {}) => {
        if (!db || !userId) throw new Error("Database not connected or user not authenticated.");
        const requestDocRef = doc(db, "artifacts", appId, "public", "data", "letter_requests", requestId);
        
        const updateData = {
            status: newStatus,
            resolvedBy: userId,
            resolvedAt: serverTimestamp(),
            ...details
        };

        await updateDoc(requestDocRef, updateData);
    };

    const handleMarkAsPaid = async (requestId) => {
        if (!db) return;
        const requestDocRef = doc(db, "artifacts", appId, "public", "data", "letter_requests", requestId);
        try {
            await updateDoc(requestDocRef, {
                "payment.status": "paid"
            });
        } catch (err) {
            console.error("Failed to mark as paid:", err);
            alert("Could not update payment status.");
        }
    };

    // --- Modal Handlers ---
    const handleOpenReviewModal = (request) => {
        setSelectedRequest(request);
        setNidaVerificationStatus('idle');
        setIsReviewModalOpen(true);
        setShowEscalateForm(false);
        setEscalationNotes("");
        setModalError("");
    };

    const handleCloseModals = () => {
        setIsReviewModalOpen(false);
        setIsPaymentModalOpen(false);
        setIsRejectionModalOpen(false);
        setIsLetterModalOpen(false);
        setSelectedRequest(null);
        setModalError("");
    };

    const handleOpenRejectionModal = () => {
        setIsReviewModalOpen(false);
        setRejectionReason("");
        setRejectionNotes("");
        setModalError("");
        setIsRejectionModalOpen(true);
    };
    
    const handleOpenLetterModal = (request) => {
        setSelectedRequest(request);
        setIsLetterModalOpen(true);
    };

    const handleNidaVerification = async () => {
        setNidaVerificationStatus('pending');
        await new Promise(resolve => setTimeout(resolve, 2000));
        const isSuccess = Math.random() > 0.3;
        setNidaVerificationStatus(isSuccess ? 'success' : 'failed');
    };

    const handleConfirmRejection = async () => {
        if (!selectedRequest) return;
        if (!rejectionReason) {
            setModalError("Please select a reason for rejection.");
            return;
        }
        if (!rejectionNotes.trim()) {
            setModalError("Rejection notes are required.");
            return;
        }
        try {
            const rejectionDetails = {
                rejection: {
                    reason: rejectionReason,
                    notes: rejectionNotes,
                }
            };
            await updateRequestStatus(selectedRequest.id, 'rejected', rejectionDetails);
            await createNotification(selectedRequest.userId, `Your request was rejected: ${rejectionReason}`);
            handleCloseModals();
        } catch (err) {
            setModalError(err.message || "An unexpected error occurred.");
        }
    };
    
    const handleEscalate = async () => {
        if (!selectedRequest || !escalationNotes.trim()) {
            setModalError("Please provide notes for the escalation.");
            return;
        }
        try {
            const escalationDetails = {
                escalation: {
                    status: `pending_${escalateTo.toLowerCase()}`,
                    escalatedTo: escalateTo,
                    notes: escalationNotes,
                    escalatedBy: userId,
                    escalatedAt: serverTimestamp(),
                }
            };
            await updateRequestStatus(selectedRequest.id, 'escalated', escalationDetails);
            await createNotification(selectedRequest.userId, `Your request has been escalated for further review.`);
            handleCloseModals();
        } catch (err) {
            setModalError(err.message || "An unexpected error occurred.");
        }
    };

    const handleOpenPaymentModal = () => {
        if (!selectedRequest?.applicant?.serviceType) {
            alert("Error: Service type not defined for this applicant.");
            return;
        }
        setIsReviewModalOpen(false);
        setPaymentControlNumber(`99${Math.floor(1000000000 + Math.random() * 9000000000)}`);
        setIsPaymentModalOpen(true);
    };

    const handleConfirmApproval = async () => {
        if (!selectedRequest || !paymentControlNumber) {
            setModalError("A payment control number is required.");
            return;
        }
        const serviceType = selectedRequest.applicant.serviceType;
        const paymentDetails = {
            payment: {
                controlNumber: paymentControlNumber,
                feeType: serviceType,
                amount: FEE_OPTIONS[serviceType],
                status: 'pending'
            }
        };
        try {
            await updateRequestStatus(selectedRequest.id, 'approved', paymentDetails);
            await createNotification(selectedRequest.userId, `Your request has been approved! Payment is now due.`);
            handleCloseModals();
        } catch (err) {
            setModalError(err.message || "Failed to approve and save payment number.");
        }
    };

    // --- Test Data Handler ---
    const addTestData = async (isParentNida = false) => {
        if (!db || !userId) return;
        const requestsRef = collection(db, "artifacts", appId, "public", "data", "letter_requests");
        
        let testData;
        if (isParentNida) {
            testData = {
                userId: `user_${Math.random().toString(36).substr(2, 9)}`,
                status: 'pending_review',
                createdAt: serverTimestamp(),
                applicant: {
                    fullName: "Baraka Mzazi",
                    dateOfBirth: "2005-08-20",
                    currentAddress: "456 Mtaa wa Jirani, Arusha",
                    reasonForRequest: "School admission requirement.",
                    imageUrl: "https://placehold.co/150x150/CDD6DD/333?text=Photo",
                    nidaNumber: "19801020112233445566",
                    nidaHolder: "parent",
                    nationalElectionNumber: null,
                    mobileNumber: "0755 111 222",
                    email: "baraka.mzazi@example.com",
                    serviceType: "Urgent"
                },
                verification: {
                    method: 'BIRTH_CERTIFICATE',
                    identifier: 'BC-554433',
                    details: {},
                    documentUrl: 'https://placehold.co/600x400/cdd6dd/333?text=Birth+Certificate'
                }
            };
        } else {
            testData = {
                userId: `user_${Math.random().toString(36).substr(2, 9)}`,
                status: 'pending_review',
                createdAt: serverTimestamp(),
                applicant: {
                    fullName: "Asha Juma",
                    dateOfBirth: "1995-03-15",
                    currentAddress: "123 Mtaa wa Amani, Dar es Salaam",
                    reasonForRequest: "To open a new bank account.",
                    imageUrl: "https://placehold.co/150x150/EFEFEF/333?text=Photo",
                    nidaNumber: "19950315123456789012",
                    nidaHolder: "self",
                    nationalElectionNumber: "123456789",
                    mobileNumber: "0712 345 678",
                    email: "asha.juma@example.com",
                    serviceType: "Standard"
                },
                verification: {
                    method: 'PASSPORT',
                    identifier: 'T12345678',
                    details: { countryOfIssue: 'TANZANIA' },
                    documentUrl: 'https://placehold.co/600x400/eee/ccc?text=Passport+Copy'
                }
            };
        }
        
        try {
            await addDoc(requestsRef, testData);
            await createNotification(userId, `New request submitted by ${testData.applicant.fullName}.`);
        } catch (e) {
            console.error("Error adding test data:", e);
            setError("Could not add test data.");
        }
    };

    // --- Filter Logic ---
    const filterRequests = (requests) => {
        if (!searchTerm) return requests;
        const lowercasedTerm = searchTerm.toLowerCase();
        return requests.filter(req => 
            req.applicant?.fullName?.toLowerCase().includes(lowercasedTerm) ||
            req.applicant?.nidaNumber?.toLowerCase().includes(lowercasedTerm) ||
            req.applicant?.email?.toLowerCase().includes(lowercasedTerm)
        );
    };

    const filteredPending = filterRequests(pendingRequests);
    const filteredProcessed = filterRequests(processedRequests);

    // --- Render Logic ---
    const renderApplicationDetails = (request) => {
        const { applicant, verification } = request;
        return (
            <div className="space-y-4 text-sm">
                <div className="p-4 bg-gray-50 rounded-lg border">
                    <h4 className="font-semibold text-gray-800 mb-3 text-base">Applicant Details</h4>
                    <div className="flex flex-col md:flex-row gap-6">
                        <div className="flex-shrink-0">
                            <img 
                                src={applicant?.imageUrl || 'https://placehold.co/150x150/EFEFEF/333?text=No+Image'} 
                                alt="Applicant" 
                                className="w-32 h-32 rounded-lg object-cover border-2 border-gray-200"
                                onError={(e) => { e.target.onerror = null; e.target.src='https://placehold.co/150x150/EFEFEF/333?text=Error'; }}
                            />
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3 flex-grow">
                            <div><strong>Full Name:</strong><p className="text-gray-700">{applicant?.fullName || 'N/A'}</p></div>
                            <div><strong>Date of Birth:</strong><p className="text-gray-700">{applicant?.dateOfBirth || 'N/A'}</p></div>
                            <div><strong>NIDA Number:</strong><p className="text-gray-700 font-mono">{applicant?.nidaNumber || 'N/A'}</p></div>
                            <div><strong>National Election No:</strong><p className="text-gray-700 font-mono">{applicant?.nationalElectionNumber || 'N/A'}</p></div>
                             <div><strong>Service Type:</strong><p className="text-gray-700 font-semibold">{applicant?.serviceType || 'N/A'}</p></div>
                            <div className="sm:col-span-2"><strong>Email:</strong><p className="text-gray-700">{applicant?.email || 'N/A'}</p></div>
                            <div className="sm:col-span-2"><strong>Address:</strong><p className="text-gray-700">{applicant?.currentAddress || 'N/A'}</p></div>
                            <div className="sm:col-span-2"><strong>Reason for Request:</strong><p className="text-gray-700">{applicant?.reasonForRequest || 'N/A'}</p></div>
                        </div>
                    </div>
                </div>
                
                {applicant?.nidaHolder === 'parent' && (
                    <div className="p-3 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800">
                        <p><strong className="font-bold">Note:</strong> Applicant is using a parent's NIDA. Additional identification is required for verification.</p>
                    </div>
                )}

                <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <div className="flex justify-between items-start">
                        <h4 className="font-semibold text-blue-800 mb-2">Verification Information</h4>
                         {applicant?.nidaHolder !== 'parent' && (
                            <button 
                                onClick={handleNidaVerification} 
                                disabled={nidaVerificationStatus === 'pending'}
                                className="bg-blue-600 text-white font-bold py-1 px-3 rounded-lg text-xs hover:bg-blue-700 disabled:bg-gray-400"
                            >
                                {nidaVerificationStatus === 'pending' ? 'Verifying...' : 'Verify with NIDA'}
                            </button>
                         )}
                    </div>
                    {nidaVerificationStatus === 'pending' && <div className="text-center p-2 text-blue-700">Simulating NIDA API call...</div>}
                    {nidaVerificationStatus === 'success' && <div className="text-center p-2 text-green-700 font-bold bg-green-100 rounded-md">✔️ NIDA Record Verified Successfully</div>}
                    {nidaVerificationStatus === 'failed' && <div className="text-center p-2 text-red-700 font-bold bg-red-100 rounded-md">❌ NIDA Record Mismatch. Please escalate.</div>}
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2 mt-2">
                        <p><strong>ID Method:</strong> <span className="font-mono bg-blue-200 text-blue-900 px-2 py-1 rounded">{verification?.method.replace('_', ' ')}</span></p>
                        <p><strong>Identifier:</strong> {verification?.identifier}</p>
                        {verification?.method === 'PASSPORT' && <p><strong>Country of Issue:</strong> {verification?.details.countryOfIssue}</p>}
                        <p className="md:col-span-2"><strong>Supporting Document:</strong> 
                            <a href={verification?.documentUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline ml-2">View Uploaded Document</a>
                        </p>
                    </div>
                </div>
            </div>
        );
    };
    
    const renderStatusBadge = (status) => {
        switch(status) {
            case 'approved': return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">Approved</span>;
            case 'rejected': return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">Rejected</span>;
            case 'escalated': return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-orange-100 text-orange-800">Escalated</span>;
            default: return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-800">{status}</span>;
        }
    };
    
    const renderPaymentStatusBadge = (paymentStatus) => {
        if (paymentStatus === 'paid') {
            return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">Paid</span>;
        }
        if (paymentStatus === 'pending') {
            return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">Pending Payment</span>;
        }
        return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-800">N/A</span>;
    };

    if (isLoading) return <Spinner />;
    if (error) return <ErrorDisplay message={error} />;

    return (
        <div className="p-4 sm:p-6 lg:px-8 bg-gray-50 min-h-screen font-sans">
            <div className="max-w-full mx-auto">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-800">Application Dashboard</h1>
                        <p className="text-sm text-gray-500 mt-1">Your Admin ID: <span className="font-mono bg-gray-200 px-1 rounded">{userId || '...'}</span></p>
                    </div>
                    <div className="flex items-center space-x-4">
                        <NotificationBell db={db} userId={userId} />
                        <button onClick={() => addTestData(false)} disabled={!isAuthReady} className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg transition-colors disabled:bg-gray-400">
                            Add Test Request
                        </button>
                         <button onClick={() => addTestData(true)} disabled={!isAuthReady} className="bg-purple-500 hover:bg-purple-600 text-white font-bold py-2 px-4 rounded-lg transition-colors disabled:bg-gray-400">
                            Add Parent NIDA Test
                        </button>
                    </div>
                </div>

                {/* Role Switcher for Demo */}
                <div className="mb-4 p-2 bg-gray-200 rounded-lg flex items-center space-x-4">
                    <span className="font-bold text-sm">Switch Role:</span>
                    <button onClick={() => setUserRole('admin')} className={`px-3 py-1 text-xs rounded-full ${userRole === 'admin' ? 'bg-blue-600 text-white' : 'bg-white text-gray-700'}`}>Admin</button>
                    <button onClick={() => setUserRole('approver')} className={`px-3 py-1 text-xs rounded-full ${userRole === 'approver' ? 'bg-green-600 text-white' : 'bg-white text-gray-700'}`}>Approver</button>
                    <button onClick={() => setUserRole('reviewer')} className={`px-3 py-1 text-xs rounded-full ${userRole === 'reviewer' ? 'bg-yellow-500 text-white' : 'bg-white text-gray-700'}`}>Reviewer</button>
                </div>

                {/* Tabs and Search */}
                <div className="mb-4">
                    <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
                        <div className="border-b border-gray-200">
                            <nav className="-mb-px flex space-x-6" aria-label="Tabs">
                                <button
                                    onClick={() => setActiveTab('pending')}
                                    className={`${activeTab === 'pending' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                                >
                                    Pending Queue
                                    <span className="ml-2 inline-block py-0.5 px-2.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">{pendingRequests.length}</span>
                                </button>
                                {userRole === 'admin' && (
                                    <button
                                        onClick={() => setActiveTab('history')}
                                        className={`${activeTab === 'history' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                                    >
                                        Request History
                                    </button>
                                )}
                            </nav>
                        </div>
                        {userRole === 'admin' && (
                            <div className="w-full sm:w-auto">
                                <input 
                                    type="text"
                                    placeholder="Search by name, NIDA, email..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="w-full sm:w-64 p-2 border rounded-md shadow-sm"
                                />
                            </div>
                        )}
                    </div>
                </div>

                {/* Content based on active tab */}
                {activeTab === 'pending' ? (
                    filteredPending.length === 0 ? (
                        <div className="text-center py-16 bg-white shadow-md rounded-lg"><p className="text-gray-500">No pending requests found.</p></div>
                    ) : (
                        <div className="bg-white shadow-md rounded-lg overflow-x-auto">
                            <table className="min-w-full leading-normal">
                                <thead>
                                    <tr className="bg-gray-100 text-left text-gray-600 uppercase text-sm">
                                        <th className="py-3 px-6">Applicant Name</th>
                                        <th className="py-3 px-6">Application Date</th>
                                        <th className="py-3 px-6">Service Type</th>
                                        <th className="py-3 px-6">Actions</th>
                                    </tr>
                                </thead>
                                <tbody className="text-gray-700">
                                    {filteredPending.map(req => (
                                        <tr key={req.id} className="border-b border-gray-200 hover:bg-gray-50">
                                            <td className="py-4 px-6 text-sm font-medium">{req.applicant?.fullName || 'N/A'}</td>
                                            <td className="py-4 px-6 text-sm">{req.createdAt?.toDate().toLocaleDateString()}</td>
                                            <td className="py-4 px-6 text-sm font-semibold">{req.applicant?.serviceType || 'N/A'}</td>
                                            <td className="py-4 px-6">
                                                <button onClick={() => handleOpenReviewModal(req)} className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-1 px-3 rounded-lg text-xs">Review</button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )
                ) : (
                    userRole === 'admin' && (
                        filteredProcessed.length === 0 ? (
                            <div className="text-center py-16 bg-white shadow-md rounded-lg"><p className="text-gray-500">No processed requests in history.</p></div>
                        ) : (
                            <div className="bg-white shadow-md rounded-lg overflow-x-auto">
                                <table className="min-w-full leading-normal">
                                    <thead>
                                        <tr className="bg-gray-100 text-left text-gray-600 uppercase text-sm">
                                            <th className="py-3 px-6">Applicant Name</th>
                                            <th className="py-3 px-6">Resolved Date</th>
                                            <th className="py-3 px-6">Status</th>
                                            <th className="py-3 px-6">Payment Status</th>
                                            <th className="py-3 px-6">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody className="text-gray-700">
                                        {filteredProcessed.map(req => (
                                            <tr key={req.id} className="border-b border-gray-200 hover:bg-gray-50">
                                                <td className="py-4 px-6 text-sm font-medium">{req.applicant?.fullName || 'N/A'}</td>
                                                <td className="py-4 px-6 text-sm">{req.resolvedAt?.toDate().toLocaleDateString() || 'N/A'}</td>
                                                <td className="py-4 px-6">{renderStatusBadge(req.status)}</td>
                                                <td className="py-4 px-6">{renderPaymentStatusBadge(req.payment?.status)}</td>
                                                <td className="py-4 px-6 space-x-2">
                                                    {req.status === 'approved' && req.payment?.status === 'pending' && (
                                                        <button onClick={() => handleMarkAsPaid(req.id)} className="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-1 px-3 rounded-lg text-xs">
                                                            Mark as Paid
                                                        </button>
                                                    )}
                                                    {req.status === 'approved' && (
                                                        <button onClick={() => handleOpenLetterModal(req)} className="bg-indigo-500 hover:bg-indigo-600 text-white font-bold py-1 px-3 rounded-lg text-xs disabled:bg-gray-400" disabled={req.payment?.status !== 'paid'}>
                                                            Generate Letter
                                                        </button>
                                                    )}
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )
                    )
                )}
            </div>

            {/* Modals */}
            {isReviewModalOpen && selectedRequest && (
                <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4">
                    <div className="bg-white rounded-lg shadow-2xl p-6 max-w-5xl w-full overflow-y-auto" style={{maxHeight: '90vh'}}>
                        <h3 className="text-xl font-bold mb-4">Review Full Application</h3>
                        {renderApplicationDetails(selectedRequest)}
                        {showEscalateForm && (userRole === 'admin' || userRole === 'reviewer') && (
                            <div className="mt-4 p-4 border-2 border-dashed border-orange-400 rounded-lg space-y-3">
                                <h4 className="font-bold text-orange-600">Escalate for External Verification</h4>
                                <div>
                                    <label htmlFor="escalateTo" className="block text-sm font-medium">Escalate To:</label>
                                    <select id="escalateTo" value={escalateTo} onChange={(e) => setEscalateTo(e.target.value)} className="w-full mt-1 p-2 border rounded-md bg-white">
                                        <option value="RITA">RITA (Birth Certificates)</option>
                                        <option value="MIGRATION">Migration (Passports)</option>
                                        <option value="POLICE">Police (General)</option>
                                        <option value="SCHOOL">School</option>
                                    </select>
                                </div>
                                <div>
                                    <label htmlFor="escalationNotes" className="block text-sm font-medium">Notes:</label>
                                    <textarea id="escalationNotes" value={escalationNotes} onChange={(e) => setEscalationNotes(e.target.value)} className="w-full mt-1 p-2 border rounded-md" rows="3" placeholder="Reason for escalation..."></textarea>
                                </div>
                                {modalError && <p className="text-red-500 text-xs mt-1">{modalError}</p>}
                                <button onClick={handleEscalate} className="w-full px-4 py-2 bg-orange-500 text-white rounded-lg font-semibold hover:bg-orange-600">Confirm Escalation</button>
                            </div>
                        )}
                        <div className="flex justify-end mt-6 space-x-3">
                            <button onClick={handleCloseModals} className="px-4 py-2 bg-gray-300 rounded-lg font-semibold">Cancel</button>
                            {(userRole === 'admin' || userRole === 'reviewer') && (
                                <button onClick={() => setShowEscalateForm(!showEscalateForm)} className="px-4 py-2 bg-orange-400 text-white rounded-lg font-semibold hover:bg-orange-500">{showEscalateForm ? 'Cancel Escalation' : 'Escalate'}</button>
                            )}
                            {(userRole === 'admin' || userRole === 'approver') && (
                                <>
                                    <button onClick={handleOpenRejectionModal} className="px-4 py-2 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600">Reject</button>
                                    <button onClick={handleOpenPaymentModal} className="px-4 py-2 bg-green-500 text-white rounded-lg font-semibold hover:bg-green-600" disabled={nidaVerificationStatus !== 'success' && selectedRequest.applicant.nidaHolder !== 'parent'}>Approve</button>
                                </>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {isRejectionModalOpen && selectedRequest && (
                 <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4">
                    <div className="bg-white rounded-lg shadow-2xl p-6 max-w-md w-full">
                        <h3 className="text-xl font-bold mb-4">Reject Application</h3>
                        <p className="text-sm text-gray-600 mb-4">Please provide a reason for rejecting the application for <strong className="text-gray-800">{selectedRequest.applicant.fullName}</strong>.</p>
                        <div className="space-y-4">
                             <div>
                                <label htmlFor="rejectionReason" className="block text-sm font-medium text-gray-700">Reason for Rejection</label>
                                <select 
                                    id="rejectionReason"
                                    value={rejectionReason}
                                    onChange={(e) => setRejectionReason(e.target.value)}
                                    className="w-full mt-1 p-2 border rounded-md bg-white"
                                >
                                    <option value="">-- Select a reason --</option>
                                    <option value="Incomplete Information">Incomplete Information</option>
                                    <option value="Document Mismatch">Document Mismatch</option>
                                    <option value="Required to Visit Office">Required to Visit Office</option>
                                    <option value="Other">Other (Specify in notes)</option>
                                </select>
                            </div>
                            <div>
                                <label htmlFor="rejectionNotes" className="block text-sm font-medium text-gray-700">Rejection Notes</label>
                                <textarea 
                                    id="rejectionNotes"
                                    value={rejectionNotes}
                                    onChange={(e) => setRejectionNotes(e.target.value)}
                                    className="w-full mt-1 p-2 border rounded-md" 
                                    rows="3" 
                                    placeholder="Provide specific details for the rejection..."
                                ></textarea>
                            </div>
                        </div>
                        {modalError && <p className="text-red-500 text-xs mt-2">{modalError}</p>}
                        <div className="flex justify-end mt-6 space-x-3">
                            <button onClick={() => {setIsRejectionModalOpen(false); setIsReviewModalOpen(true);}} className="px-4 py-2 bg-gray-300 rounded-lg font-semibold">Back to Review</button>
                            <button onClick={handleConfirmRejection} className="px-4 py-2 bg-red-600 text-white rounded-lg font-semibold hover:bg-red-700">Confirm Rejection</button>
                        </div>
                    </div>
                </div>
            )}

            {isPaymentModalOpen && selectedRequest && (
                <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4">
                    <div className="bg-white rounded-lg shadow-2xl p-6 max-w-md w-full">
                        <h3 className="text-xl font-bold mb-4">Generate Payment Control Number</h3>
                        <p className="text-sm text-gray-600 mb-4">A control number will be generated for <strong className="text-gray-800">{selectedRequest.applicant.fullName}</strong>.</p>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Fee for {selectedRequest.applicant.serviceType} Service</label>
                                <p className="text-2xl font-bold text-gray-800 mt-1">{FEE_OPTIONS[selectedRequest.applicant.serviceType].toLocaleString()} TZS</p>
                            </div>
                            <div>
                                <label htmlFor="controlNumber" className="block text-sm font-medium text-gray-700">Payment Control Number</label>
                                <input 
                                    type="text"
                                    id="controlNumber"
                                    value={paymentControlNumber}
                                    readOnly
                                    className="w-full mt-1 p-2 border rounded-md bg-gray-100 font-mono text-center"
                                />
                            </div>
                        </div>
                        {modalError && <p className="text-red-500 text-xs mt-2">{modalError}</p>}
                        <div className="flex justify-end mt-6 space-x-3">
                            <button onClick={() => {setIsPaymentModalOpen(false); setIsReviewModalOpen(true);}} className="px-4 py-2 bg-gray-300 rounded-lg font-semibold">Back to Review</button>
                            <button onClick={handleConfirmApproval} className="px-4 py-2 bg-green-500 text-white rounded-lg font-semibold hover:bg-green-600">Confirm & Approve</button>
                        </div>
                    </div>
                </div>
            )}

            {isLetterModalOpen && selectedRequest && (
                 <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4">
                    <div className="bg-white rounded-lg shadow-2xl p-6 max-w-2xl w-full">
                        <h2 className="text-2xl font-bold mb-4">Residence Letter is Ready</h2>
                        <div className="mb-6 p-4 border rounded-md bg-gray-50">
                            <p><strong>Name:</strong> {selectedRequest.applicant.fullName}</p>
                            <p><strong>Address:</strong> {selectedRequest.applicant.currentAddress}</p>
                             <p><strong>Control Number:</strong> {selectedRequest.payment.controlNumber}</p>
                        </div>
                        <button 
                            onClick={() => generateResidenceLetterPDF(selectedRequest)}
                            className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-lg shadow-md"
                        >
                            Download as PDF
                        </button>
                        <button onClick={handleCloseModals} className="w-full mt-3 bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 rounded-lg">
                            Close
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
}
